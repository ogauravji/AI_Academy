
import React from "react";
import { motion, useInView } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Award, 
  Users, 
  TrendingUp,
  CheckCircle2
} from "lucide-react";

const achievements = [
  "15+ years in digital marketing & tech startups",
  "Trained 9,000+ professionals across MENA",
  "Worked with 300+ agencies",
  "Former Google Regional Trainer",
  "Dubai Tourism consultant for Expo 2020",
  "TikTok MENA collaborator",
  "Active investor & startup advisor"
];

export default function InstructorProfile() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} id="instructor" className="py-20 sm:py-24 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12 sm:mb-16"
        >
          <Badge variant="outline" className="px-4 py-2 text-sm font-medium border-blue-200 text-blue-700 mb-4">
            <Award className="w-4 h-4 mr-2" />
            World-Class Instruction
          </Badge>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900">
            Meet Your 
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Expert Trainer</span>
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-8 lg:gap-12 items-center">
          {/* Profile Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-2"
          >
            <div className="aspect-w-1 aspect-h-1 lg:aspect-w-4 lg:aspect-h-5">
              <img 
                 src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/5bb702e8b_Gaurav_SiFi.png" 
                 alt="Gaurav Oberoi - Expert AI marketing trainer" 
                 className="w-full h-full object-cover rounded-2xl shadow-lg"
                 loading="lazy"
                 decoding="async" 
               />
            </div>
          </motion.div>

          {/* Profile Content */}
          <motion.div
             initial={{ opacity: 0, x: 50 }}
             animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
             transition={{ duration: 0.8, delay: 0.2 }}
             className="lg:col-span-3"
          >
            <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">
              Gaurav Oberoi
            </h3>
            <p className="text-lg text-blue-600 font-semibold mb-4">
              Founder, Trainer & Fractional CMO
            </p>
            
            <p className="text-base text-gray-600 mb-6 leading-relaxed">
              A globally recognized marketing expert who has trained thousands of professionals 
              and worked with industry leaders across the MENA region. Known for delivering 
              highly engaging, practical training that transforms how executives think about 
              marketing technology.
            </p>

            {/* Key Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <Card className="border-0 bg-gray-50/70">
                <CardContent className="p-4 flex items-center gap-4">
                   <div className="bg-blue-100 p-3 rounded-lg">
                    <Users className="w-6 h-6 text-blue-600" />
                   </div>
                   <div>
                    <span className="text-xl font-bold text-gray-900">9,000+</span>
                    <p className="text-sm text-gray-600">Professionals Trained</p>
                   </div>
                </CardContent>
              </Card>
              
              <Card className="border-0 bg-gray-50/70">
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <span className="text-xl font-bold text-gray-900">15+</span>
                    <p className="text-sm text-gray-600">Years Experience</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Achievements */}
            <div className="space-y-3 text-sm">
              {achievements.map((achievement, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
                  transition={{ duration: 0.5, delay: 0.4 + index * 0.05 }}
                  className="flex items-center gap-3"
                >
                  <CheckCircle2 className="w-5 h-5 text-blue-500 flex-shrink-0" />
                  <span className="text-gray-700">{achievement}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
