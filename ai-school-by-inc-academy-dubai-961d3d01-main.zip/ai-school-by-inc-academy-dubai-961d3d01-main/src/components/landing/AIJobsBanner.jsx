import React from 'react';
import { motion, useInView } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, BrainCircuit } from 'lucide-react';

export default function AIJobsBanner() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section ref={ref} className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 1 }}
          className="bg-gradient-to-r from-blue-900/50 to-purple-900/50 rounded-3xl p-8 sm:p-12"
        >
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center mb-6">
                <BrainCircuit className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                The Future of Work is Here. Are You Ready?
              </h2>
              <p className="text-lg text-gray-300 mb-8 leading-relaxed">
                AI won't take your job, but a person using AI will. This masterclass is designed to make you that person—the indispensable expert who leads with AI, not follows. Secure your role in the new economy by mastering the tools that are reshaping every industry.
              </p>
              <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-200 font-semibold px-8 py-4 rounded-xl shadow-lg group">
                Future-Proof Your Career
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
            <div className="hidden lg:flex items-center justify-center">
              <div className="relative w-full max-w-md">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full blur-3xl opacity-50"></div>
                <img src="https://images.unsplash.com/photo-1620712943543-bcc4688e7485?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=765&q=80" alt="AI Future Technology" className="relative w-full h-auto rounded-3xl z-10" />
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}