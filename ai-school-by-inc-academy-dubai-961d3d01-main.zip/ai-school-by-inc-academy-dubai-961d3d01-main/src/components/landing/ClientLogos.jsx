import React from 'react';

const clientLogos = [
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f2b001de0_5.png", alt: "Google" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a110c098b_18.png", alt: "TikTok" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/ebba4f908_24.png", alt: "Dubai Tourism" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d1e13dbdc_3.png", alt: "Emirates" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/1f7695b87_13.png", alt: "Alshaya" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/c2a949770_22.png", alt: "Unilever" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d825d99f2_6.png", alt: "Etihad" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/da941e9d4_7.png", alt: "Harvard Business School" }
];

export default function ClientLogos() {
    return (
        <section className="bg-white py-16">
            <div className="mx-auto max-w-7xl px-6 lg:px-8">
                <h2 className="text-center text-lg font-semibold leading-8 text-gray-900">
                    Trusted by professionals from the world’s leading organizations
                </h2>
                <div className="mx-auto mt-10 grid max-w-lg grid-cols-4 items-center gap-x-8 gap-y-10 sm:max-w-xl sm:grid-cols-6 sm:gap-x-10 lg:mx-0 lg:max-w-none lg:grid-cols-8">
                    {clientLogos.map((client, index) => (
                        <img key={index} className="col-span-2 max-h-12 w-full object-contain lg:col-span-1" src={client.src} alt={client.alt} width="158" height="48" />
                    ))}
                </div>
            </div>
        </section>
    );
}