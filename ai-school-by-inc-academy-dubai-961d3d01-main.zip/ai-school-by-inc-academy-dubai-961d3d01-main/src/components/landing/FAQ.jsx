
import React, { useState } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, HelpCircle } from "lucide-react";

const faqData = {
  "General": [
    {
      question: "Do I need any prior AI knowledge or technical skills?",
      answer: "Not at all. This course is designed for professionals from all backgrounds. We start with the fundamentals and focus on practical, non-technical applications of AI that you can use immediately, regardless of your role."
    },
    {
      question: "What is the difference between the Online Cohort and the Classroom Workshop?",
      answer: "The Online Cohort is a live, virtual training spread over 3 days (2 hours each day), offering flexibility. The Classroom Workshop is an intensive, full-day (8-hour) in-person session in Dubai, providing a more immersive experience with direct interaction and networking. Both cover the same core curriculum."
    },
    {
      question: "Are the fees inclusive of VAT?",
      answer: "Yes, all course fees are inclusive of the 5% UAE VAT."
    },
    {
      question: "Who is the trainer for this course?",
      answer: "The course is led by Gaurav Oberoi, a globally recognized marketing expert with over 15 years of experience and a former regional trainer for Google. He has trained over 9,000 professionals across the MENA region."
    }
  ],
  "Logistics & Support": [
    {
      question: "How are the bootcamps delivered?",
      answer: "Both our online cohort and in-person bootcamp in Dubai are live and interactive, led by expert trainers. You'll participate in hands-on exercises and real-time Q&A."
    },
    {
      question: "What if I can't attend a live session?",
      answer: "You can reschedule to another cohort date with at least 48 hours notice. Our methodology relies on live participation for optimal results."
    },
    {
      question: "Can I retake the course?",
      answer: "Yes, graduates can re-attend the same course for 25% discount within 12 months, subject to availability. This allows you to refresh your skills in the fast-evolving field of AI."
    }
  ],
  "Outcomes & Policies": [
    {
      question: "Will I receive a certificate upon completion?",
      answer: "Yes, upon successful completion of the course, you will receive a digital certificate from Inc. Academy, which you can share on your LinkedIn profile and resume."
    },
    {
      question: "Is there a refund policy?",
      answer: "Yes, we offer a full refund if you cancel at least 7 days before the course start date. Please refer to our terms of service for the complete policy details."
    },
    {
      question: "Does this course offer job placement assistance?",
      answer: "While this is not a job placement program, the skills you learn will significantly enhance your employability. We focus on practical skills for career growth, resume enhancement, and leveraging AI in job searches, making you a top candidate in your field."
    }
  ]
};

export default function FAQ() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [openIndex, setOpenIndex] = useState(0);

  // Flatten the faqData object into a single array for rendering
  const faqs = Object.values(faqData).flat();

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? -1 : index);
  };

  return (
    <section ref={ref} className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <Badge variant="outline" className="px-4 py-2 text-sm font-medium border-blue-200 text-blue-700 mb-6">
            <HelpCircle className="w-4 h-4 mr-2" />
            Common Questions
          </Badge>
          
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Frequently Asked
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Questions</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto font-light">
            Get answers to the most common questions about our AI training program
          </p>
        </motion.div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden">
                <CardContent className="p-0">
                  <button
                    onClick={() => toggleFAQ(index)}
                    className="w-full text-left p-6 focus:outline-none"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-gray-900 pr-4">
                        {faq.question}
                      </h3>
                      <ChevronRight 
                        className={`w-5 h-5 text-gray-400 transition-transform duration-300 flex-shrink-0 ${
                          openIndex === index ? 'rotate-90' : ''
                        }`} 
                      />
                    </div>
                  </button>
                  
                  <AnimatePresence>
                    {openIndex === index && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <div className="px-6 pb-6 pt-0">
                          <p className="text-gray-600 leading-relaxed">
                            {faq.answer}
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
