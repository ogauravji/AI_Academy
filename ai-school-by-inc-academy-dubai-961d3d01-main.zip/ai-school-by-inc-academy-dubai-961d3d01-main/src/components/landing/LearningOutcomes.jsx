import React from "react";
import { motion, useInView } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Target,
  BarChart,
  UserSearch,
  UserCheck,
  Rocket,
  PenTool,
  Briefcase,
  Calculator,
  Lightbulb,
  FileText } from
"lucide-react";

const outcomes = [
{
  icon: BarChart,
  title: "For Marketers",
  description: "Automate campaign analysis, generate high-converting copy, and build AI-powered marketing funnels to maximize ROI.",
  color: "from-blue-500 to-blue-600"
},
{
  icon: UserSearch,
  title: "For Job Seekers",
  description: "Enhance your resume, automate job searches, and master AI interview tools to land your dream job faster.",
  color: "from-green-500 to-green-600"
},
{
  icon: UserCheck,
  title: "For Executives",
  description: "Leverage AI for strategic decision-making, team productivity, and forecasting to gain a competitive edge.",
  color: "from-purple-500 to-purple-600"
},
{
  icon: Rocket,
  title: "For Entrepreneurs",
  description: "Scale your business with AI-driven operations, sales automation, and customer service solutions.",
  color: "from-orange-500 to-orange-600"
},
{
  icon: PenTool,
  title: "For Freelancers",
  description: "Boost your productivity, deliver higher quality work, and expand your service offerings with AI tools.",
  color: "from-red-500 to-red-600"
},
{
  icon: Briefcase,
  title: "For HR & Finance",
  description: "Streamline recruitment, automate financial reporting, and use predictive analytics for talent and budget management.",
  color: "from-indigo-500 to-indigo-600"
},
{
  icon: Lightbulb,
  title: "For Consultants",
  description: "Provide data-driven insights, automate report generation, and deliver more value to your clients with AI.",
  color: "from-pink-500 to-pink-600"
},
{
  icon: FileText,
  title: "For Analysts",
  description: "Automate data collection, perform complex analysis in seconds, and generate insightful reports effortlessly.",
  color: "from-cyan-500 to-cyan-600"
}];


export default function LearningOutcomes() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="bg-white px-4 py-6 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16">

          <Badge variant="outline" className="px-6 py-3 text-base font-medium border-green-200 text-green-700 mb-8">
            <Target className="w-5 h-5 mr-2" />
            What You'll Achieve
          </Badge>
          
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            AI Skills for 
            <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent"> Every Professional</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
            This program is designed to equip professionals from all fields with practical AI skills 
            to boost productivity, drive innovation, and advance their careers.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {outcomes.map((outcome, index) =>
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}>

              <Card className="h-full hover:shadow-xl transition-all duration-300 group border-0 bg-gradient-to-br from-white to-gray-50 overflow-hidden">
                <div className={`h-1 bg-gradient-to-r ${outcome.color}`}></div>
                <CardContent className="p-8">
                  <div className={`w-16 h-16 mb-6 rounded-2xl bg-gradient-to-r ${outcome.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <outcome.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">{outcome.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{outcome.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </section>);

}