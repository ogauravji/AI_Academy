import React from "react";
import { motion, useInView } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Clock, DollarSign } from "lucide-react";

const outcomes = [
  {
    icon: Clock,
    metric: "70%",
    description: "Reduction in content creation time",
    case: "Real Estate Agency automated social posts and email campaigns",
    color: "from-blue-500 to-blue-600"
  },
  {
    icon: TrendingUp,
    metric: "3x",
    description: "More campaigns launched per month",
    case: "SaaS startup scaled marketing with AI-powered automation",
    color: "from-green-500 to-green-600"
  },
  {
    icon: DollarSign,
    metric: "$40K",
    description: "Generated in 60 days using AI funnels",
    case: "E-commerce founder implemented conversion optimization",
    color: "from-purple-500 to-purple-600"
  }
];

export default function RealOutcomes() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <Badge variant="outline" className="px-4 py-2 text-sm font-medium border-blue-200 text-blue-700 mb-6">
            <TrendingUp className="w-4 h-4 mr-2" />
            Proven Results
          </Badge>
          
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Real 
            <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent"> Outcomes</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto font-light">
            See the measurable impact our graduates achieve when they implement 
            AI strategies in their businesses
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {outcomes.map((outcome, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
            >
              <Card className="h-full bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 group overflow-hidden">
                <div className={`h-1 bg-gradient-to-r ${outcome.color}`}></div>
                <CardContent className="p-8 text-center">
                  <div className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-r ${outcome.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <outcome.icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <div className="text-4xl sm:text-5xl font-bold text-gray-900 mb-2">
                    {outcome.metric}
                  </div>
                  
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">
                    {outcome.description}
                  </h3>
                  
                  <p className="text-gray-600 leading-relaxed">
                    {outcome.case}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}