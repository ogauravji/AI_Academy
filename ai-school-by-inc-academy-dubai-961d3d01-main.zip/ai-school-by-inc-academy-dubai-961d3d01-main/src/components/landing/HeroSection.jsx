import React from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Brain } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function HeroSection() {
    return (
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-gray-900 via-blue-900 to-black text-white">
            <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
            <div className="relative z-10 mx-auto px-4 py-16 sm:px-6 lg:px-8 max-w-7xl">
                <div className="grid lg:grid-cols-2 gap-12 items-center">
                    <div className="text-center lg:text-left">
                        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="mb-6">
                            <Badge className="px-6 py-3 text-base font-semibold bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-full shadow-lg">
                                <Brain className="w-5 h-5 mr-3" />
                                Trusted by 9,000+ Professionals
                            </Badge>
                        </motion.div>
                        <motion.h1 initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                            The AI Revolution is Here.
                            <span className="bg-gradient-to-r from-blue-400 via-green-400 to-red-400 bg-clip-text text-transparent block">Will You Lead or Follow?</span>
                        </motion.h1>
                        <motion.p initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }} className="text-lg sm:text-xl text-gray-300 mb-10 max-w-3xl mx-auto lg:mx-0">
                            Master Generative AI before your competition does. Executive-level training that transforms careers and future-proofs businesses.
                        </motion.p>
                        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.6 }} className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                            <Link to={createPageUrl("ai-courses")}>
                                <Button size="lg" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-lg">
                                    Explore AI Courses <ArrowRight className="w-5 h-5 ml-2" />
                                </Button>
                            </Link>
                            <Link to={createPageUrl("corporate-ai-workshops")}>
                                <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent hover:bg-white/10 border-white text-white px-8 py-4 text-lg font-semibold rounded-xl">
                                    For Corporate Teams
                                </Button>
                            </Link>
                        </motion.div>
                    </div>
                    <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, delay: 0.4 }} className="relative hidden lg:block">
                        <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/dbd194a74_TheAIRevolution.jpeg" alt="AI Revolution concept" className="rounded-3xl shadow-2xl" />
                    </motion.div>
                </div>
            </div>
        </section>
    );
}