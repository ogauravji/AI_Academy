
import React from "react";
import { motion, useInView } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Target, Briefcase, TrendingUp, Crown, Rocket, CheckCircle2 } from "lucide-react";

const audienceTypes = [
  {
    icon: Crown,
    title: "Founders & CEOs",
    description: "Scale startups with AI-powered marketing strategies",
    color: "from-purple-500 to-purple-600"
  },
  {
    icon: Target,
    title: "CMOs & Marketing Directors",
    description: "Drive innovation and lead marketing transformation",
    color: "from-blue-500 to-blue-600"
  },
  {
    icon: TrendingUp,
    title: "Heads of Growth",
    description: "Build AI-powered funnels and optimization systems",
    color: "from-green-500 to-green-600"
  },
  {
    icon: Briefcase,
    title: "Business Owners",
    description: "Implement AI tools for competitive advantage",
    color: "from-orange-500 to-orange-600"
  }
];

export default function TargetAudience() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <Badge variant="outline" className="px-4 py-2 text-sm font-medium border-blue-200 text-blue-700 mb-6">
            <Users className="w-4 h-4 mr-2" />
            Executive-Level Training
          </Badge>
          
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Designed for 
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"> Decision-Makers</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-3xl mx-auto font-light">
            This isn't for developers. It's for strategic leaders who want to harness AI 
            for business growth, operational efficiency, and market leadership.
          </p>
        </motion.div>

        {/* No-Code Emphasis Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-3xl p-8 mb-16 border border-green-200"
        >
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              100% <span className="text-green-600">No-Code Required</span>
            </h3>
            <p className="text-xl text-gray-700 mb-8 max-w-3xl mx-auto leading-relaxed">
              You don't need to be a programmer, data scientist, or have any technical background. 
              This course is designed for business professionals who want to leverage AI tools through 
              user-friendly interfaces and strategic implementation.
            </p>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white/80 p-6 rounded-xl border border-green-100">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-green-600" />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">No Programming</h4>
                <p className="text-gray-600 text-sm">Zero coding skills required. We use point-and-click AI tools that anyone can master.</p>
              </div>
              
              <div className="bg-white/80 p-6 rounded-xl border border-green-100">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Target className="w-6 h-6 text-green-600" />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Business-Focused</h4>
                <p className="text-gray-600 text-sm">Learn practical applications that directly impact your marketing ROI and business growth.</p>
              </div>
              
              <div className="bg-white/80 p-6 rounded-xl border border-green-100">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Rocket className="w-6 h-6 text-green-600" />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Immediate Results</h4>
                <p className="text-gray-600 text-sm">Start implementing AI solutions in your work from day one, no technical setup required.</p>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {audienceTypes.map((audience, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="relative h-full hover:shadow-xl transition-all duration-300 group border-0 bg-gradient-to-br from-white to-gray-50 overflow-hidden">
                <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${audience.color}`}></div>
                <CardContent className="p-8 text-center">
                  <div className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-r ${audience.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <audience.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">{audience.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{audience.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-8 sm:p-12">
            <h3 className="text-2xl sm:text-3xl font-bold text-white mb-4">
              Perfect for Leaders Who Want to
            </h3>
            <div className="grid sm:grid-cols-2 gap-4 text-left text-gray-300 max-w-4xl mx-auto">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Drive AI adoption across marketing teams</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Implement ROI-driven AI frameworks</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Build a lasting competitive advantage</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Scale operations without scaling headcount</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Future-proof their marketing strategy</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span>Lead organizational change with confidence</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
