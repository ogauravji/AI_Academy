
import React from "react";
import { motion, useInView } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Brain, 
  BarChart3, 
  PenSquare, 
  Presentation, 
  UserSearch,
  BookOpen,
  Mail,
  Film,
  Award,
  FileText,
  Rocket,
  MessageSquare,
  Percent,
  Zap,
  Bot,
  Shield,
  Globe,
  TrendingUp,
  Settings,
  Database,
  Code
} from "lucide-react";

const modules = [
  {
    icon: Brain,
    level: 'Basic',
    title: "AI Fundamentals & Prompting",
    description: "Master ChatGPT and 15+ other AI tools to build a solid foundation for practical application in any professional role.",
    color: "from-purple-500 to-purple-600",
  },
  {
    icon: BarChart3,
    level: 'Basic',
    title: "AI for Data Analysis",
    description: "Turn raw data into actionable insights. Use AI to analyze spreadsheets, create charts, and forecast trends without complex formulas.",
    color: "from-blue-500 to-blue-600",
  },
  {
    icon: PenSquare,
    level: 'Basic',
    title: "AI for Content Creation",
    description: "Generate high-quality copy, blog posts, social media updates, and creative content in a fraction of the time.",
    color: "from-green-500 to-green-600",
  },
  {
    icon: Presentation,
    level: 'Intermediate',
    title: "AI-Powered Presentations",
    description: "Build compelling PowerPoint and Google Slides presentations 10x faster, from outline to final design.",
    color: "from-orange-500 to-orange-600",
  },
  {
    icon: UserSearch,
    level: 'Intermediate',
    title: "AI for Career Growth",
    description: "Accelerate your job hunt or build a powerful personal brand. Use AI to optimize your resume, LinkedIn, and networking.",
    color: "from-red-500 to-red-600",
  },
  {
    icon: BookOpen,
    level: 'Intermediate',
    title: "Elevate Reading & Research",
    description: "Consume and synthesize information instantly. Use AI to summarize long articles, research papers, and books in seconds.",
    color: "from-indigo-500 to-indigo-600",
  },
  {
    icon: Mail,
    level: 'Intermediate',
    title: "Supercharge Email Productivity",
    description: "Master your inbox with AI. Write effective emails, achieve inbox zero, and automate follow-ups effortlessly.",
    color: "from-pink-500 to-pink-600",
  },
  {
    icon: Film,
    level: 'Intermediate',
    title: "AI Audio & Video Creation",
    description: "Explore the cutting edge of AI content. Create professional voiceovers, edit videos with text commands, and generate AI avatars.",
    color: "from-cyan-500 to-cyan-600",
  },
  {
    icon: Bot,
    title: "Workflow Automation & AI Agents",
    level: 'Advanced',
    description: "Build custom AI agents and automated workflows. Connect AI tools to streamline repetitive tasks and create intelligent business processes.",
    color: "from-violet-500 to-purple-600",
  },
  {
    icon: Code,
    title: "API Integrations & Custom Solutions",
    level: 'Advanced',
    description: "Connect AI models through APIs to create custom business solutions without coding knowledge.",
    color: "from-slate-500 to-gray-600",
  },
  {
    icon: Database,
    title: "AI-Powered Analytics & Insights",
    level: 'Advanced',
    description: "Build predictive models and advanced analytics dashboards using AI for strategic decision-making.",
    color: "from-emerald-500 to-teal-600",
  },
  {
    icon: Shield,
    title: "AI Ethics & Governance Frameworks",
    level: 'Advanced',
    description: "Implement responsible AI practices and governance frameworks for enterprise-level deployment.",
    color: "from-rose-500 to-pink-600",
  },
  {
    icon: Globe,
    title: "Multi-Language AI Applications",
    level: 'Advanced',
    description: "Deploy AI solutions across different languages and cultural contexts for global business operations.",
    color: "from-amber-500 to-orange-600",
  },
  {
    icon: TrendingUp,
    title: "AI-Driven Business Strategy",
    level: 'Advanced',
    description: "Develop comprehensive AI transformation strategies that align with business goals and drive competitive advantage.",
    color: "from-purple-500 to-indigo-600",
  },
  {
    icon: Settings,
    title: "Advanced AI System Architecture",
    level: 'Advanced',
    description: "Design and implement complex AI ecosystems that integrate multiple tools and workflows for maximum efficiency.",
    color: "from-gray-500 to-slate-600",
  }
];

const bonusMaterials = [
  {
    icon: FileText,
    title: "200+ Prompt Library",
    description: "Ready-to-use prompts for every business scenario",
  },
  {
    icon: Rocket,
    title: "50+ AI Tools Database",
    description: "Curated list with use cases, pricing, and guides",
  },
  {
    icon: MessageSquare,
    title: "WhatsApp Community",
    description: "Lifetime access to a private network of AI professionals",
  },
  {
    icon: Percent,
    title: "Exclusive Discounts",
    description: "Special pricing on future advanced AI workshops",
  }
];

export default function CourseModules() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} id="modules" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <Badge variant="outline" className="px-6 py-3 text-base font-medium border-blue-200 text-blue-700 mb-8">
            <Brain className="w-5 h-5 mr-2" />
            Comprehensive AI Curriculum
          </Badge>
          
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Complete AI
            <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent"> Mastery Path</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
            From foundational skills to advanced system architecture, master every aspect of AI implementation for business growth.
          </p>
        </motion.div>

        {/* Course Modules Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {modules.map((module, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
            >
              <Card className={`relative h-full hover:shadow-xl transition-all duration-300 group border-0 bg-white overflow-hidden`}>
                <div className={`h-1 bg-gradient-to-r ${module.color}`}></div>
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${module.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                      <module.icon className="w-6 h-6 text-white" />
                    </div>
                     <Badge className={`font-bold ${
                        module.level === 'Basic' ? 'bg-green-100 text-green-800' :
                        module.level === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                    }`}>{module.level}</Badge>
                  </div>
                  <CardTitle className="text-xl font-bold text-gray-900 mb-2">
                    {module.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0 space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    {module.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Programs Section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center mb-16"
        >
          <h3 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-12">
            Choose Your Learning Path
          </h3>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {/* 3-Hour Mastermind */}
            <Card className="border-2 border-blue-200 hover:border-blue-400 transition-all duration-300 hover:shadow-xl">
              <CardContent className="p-8 text-center">
                <Badge className="bg-blue-100 text-blue-800 mb-4">Introductory</Badge>
                <h4 className="text-xl font-bold mb-2">3-Hour AI Mastermind</h4>
                <p className="text-gray-600 mb-4">AI Skills to 10x Your Career in 2025</p>
                <div className="text-3xl font-bold text-blue-600 mb-4">$25</div>
                <p className="text-sm text-gray-500 mb-6">Perfect for beginners</p>
                <div className="space-y-2 text-sm text-gray-600 mb-6">
                  <div>✓ 6 Core Modules</div>
                  <div>✓ Live Q&A Session</div>
                  <div>✓ $500 Bonus Pack</div>
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Book Session
                </Button>
              </CardContent>
            </Card>

            {/* Level 1 Foundation */}
            <Card className="border-2 border-green-200 hover:border-green-400 transition-all duration-300 hover:shadow-xl relative">
              <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-green-500 text-white">Most Popular</Badge>
              <CardContent className="p-8 text-center">
                <Badge className="bg-green-100 text-green-800 mb-4">Foundation</Badge>
                <h4 className="text-xl font-bold mb-2">Level 1: AI Skills Foundation</h4>
                <p className="text-gray-600 mb-4">15-Hour Comprehensive Training</p>
                <div className="text-3xl font-bold text-green-600 mb-4">AED 3,250</div>
                <p className="text-sm text-gray-500 mb-6">Beginner to Intermediate</p>
                <div className="space-y-2 text-sm text-gray-600 mb-6">
                  <div>✓ 8 Core Modules</div>
                  <div>✓ Live Instructor-Led</div>
                  <div>✓ Certificate + Community</div>
                </div>
                <Button className="w-full bg-green-600 hover:bg-green-700">
                  Enroll Now
                </Button>
              </CardContent>
            </Card>

            {/* Level 2 Accelerator */}
            <Card className="border-2 border-purple-200 hover:border-purple-400 transition-all duration-300 hover:shadow-xl">
              <CardContent className="p-8 text-center">
                <Badge className="bg-purple-100 text-purple-800 mb-4">Advanced</Badge>
                <h4 className="text-xl font-bold mb-2">Level 2: AI Skills Accelerator</h4>
                <p className="text-gray-600 mb-4">30-Hour Advanced System Building</p>
                <div className="text-3xl font-bold text-purple-600 mb-4">AED 5,500</div>
                <p className="text-sm text-gray-500 mb-6">Advanced practitioners</p>
                <div className="space-y-2 text-sm text-gray-600 mb-6">
                  <div>✓ 7 Advanced Modules</div>
                  <div>✓ Capstone Project</div>
                  <div>✓ 1-on-1 Mentoring</div>
                </div>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">
                  Join Accelerator
                </Button>
              </CardContent>
            </Card>
          </div>
        </motion.div>

        {/* Bonus Materials Section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-3xl p-8 sm:p-12 text-white"
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl sm:text-4xl font-bold mb-4">
              Bonus Materials & Community Access
            </h3>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Walk away with battle-tested resources and lifetime access to a network of professionals.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {bonusMaterials.map((bonus, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.5, delay: 1 + index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <bonus.icon className="w-8 h-8 text-white" />
                </div>
                <h4 className="font-bold text-lg mb-2">{bonus.title}</h4>
                <p className="text-blue-100 text-sm mb-3">{bonus.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
