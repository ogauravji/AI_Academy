import React from 'react';
import { Button } from '@/components/ui/button';

export default function StripePaymentLinkButton({ href, children, ...props }) {
  const handleClick = () => {
    // Optional: Add tracking events here if needed
    if (typeof window !== 'undefined' && window.fbq) {
      window.fbq('track', 'InitiateCheckout');
    }
  };

  return (
    <Button asChild {...props}>
      <a href={href} onClick={handleClick}>
        {children}
      </a>
    </Button>
  );
}