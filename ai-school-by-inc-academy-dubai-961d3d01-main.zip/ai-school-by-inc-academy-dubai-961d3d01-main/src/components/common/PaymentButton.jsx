import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { generateCheckout } from '@/api/functions';
import { createPageUrl } from '@/utils';

export default function PaymentButton({ courseType, selectedDate, className, children, ...props }) {
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = async () => {
    setIsLoading(true);
    try {
      if (typeof window !== 'undefined' && window.fbq) {
        window.fbq('track', 'InitiateCheckout', {
          content_name: courseType,
          currency: 'USD',
        });
      }

      const successUrl = `${window.location.origin}${createPageUrl('success')}`;
      const cancelUrl = `${window.location.origin}${window.location.pathname}`;

      const { data } = await generateCheckout({
        courseType,
        successUrl,
        cancelUrl,
        selectedDate,
      });

      if (data.url) {
        window.location.href = data.url;
      } else {
        throw new Error('Failed to create Stripe checkout session.');
      }
    } catch (error) {
      console.error('Payment Error:', error);
      alert('An error occurred during the payment process. Please try again.');
      setIsLoading(false);
    }
  };

  return (
    <Button onClick={handleClick} disabled={isLoading} className={className} {...props}>
      {isLoading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Processing...
        </>
      ) : (
        children
      )}
    </Button>
  );
}