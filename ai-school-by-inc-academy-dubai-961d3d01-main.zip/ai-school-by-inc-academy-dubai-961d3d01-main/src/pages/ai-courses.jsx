import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Clock, Users, Award, ArrowRight, CheckCircle2,
  Brain, Rocket, Target, BrainCircuit, Zap, Star,
  TrendingUp, DollarSign, Briefcase, UserCheck,
  Building, Eye, Crown, Globe, BarChart3, Download,
  Code, Settings, Languages, Shield, Lightbulb,
  ChevronUp, ChevronDown, AlertTriangle, X, Infinity, Bot } from
"lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";

const courses = [
{
  id: "mastermind",
  title: "3 Hour AI Mastermind",
  subtitle: "AI Skills to 10x Your Career in 2025",
  level: "Intro",
  duration: "3 Hours",
  format: "Live Online",
  price: "$99",
  originalPrice: "$250",
  badge: "HOT",
  badgeColor: "bg-red-500 text-white",
  color: "from-red-500 to-pink-500",
  description: "Fast-track introduction to AI productivity tools and career transformation strategies.",
  highlights: [
  "Master ChatGPT, Claude, and 5+ productivity AI tools",
  "AI prompting frameworks for instant results",
  "Career positioning strategies for AI professionals",
  "Live Q&A with AI expert Gaurav Oberoi"],

  link: createPageUrl("ai-skills-mastermind"),
  icon: Zap
},
{
  id: "foundation",
  title: "AI Skills Foundation",
  subtitle: "Complete AI Training for Business Professionals",
  level: "Level 1",
  duration: "15 Hours",
  format: "Live Online Cohort",
  price: "$900",
  originalPrice: "$1250",
  badge: "MOST POPULAR",
  badgeColor: "bg-blue-500 text-white",
  color: "from-blue-500 to-indigo-500",
  description: "Comprehensive foundation in Generative AI for productivity, content creation, and AI workflow automation.",
  highlights: [
  "Master 15+ AI tools for business automation",
  "Advanced prompting and AI workflow creation",
  "Industry-specific AI implementation strategies",
  "200+ prompt library and bonus resources"],

  link: createPageUrl("ai-beginners-course"),
  icon: Brain
},
{
  id: "accelerator",
  title: "AI Skills Accelerator",
  subtitle: "Build Custom AI Systems & Automation",
  level: "Level 2",
  duration: "30 Hours",
  format: "Live Online Cohort",
  price: "$1650",
  originalPrice: "$2350",
  badge: "ADVANCED",
  badgeColor: "bg-purple-500 text-white",
  color: "from-purple-500 to-red-500",
  description: "Advanced AI in business course for building custom AI agents, AI automation, and AI-powered systems.",
  highlights: [
  "Build custom AI agents without coding",
  "Master API integrations and workflow automation",
  "Create AI-powered business solutions",
  "Capstone project with 1-on-1 mentoring"],

  link: createPageUrl("ai-advanced-course"),
  icon: Rocket
},
{
  id: "corporate",
  title: "Corporate AI Training",
  subtitle: "AI for Executives & Team Transformation",
  level: "Enterprise",
  duration: "Customized",
  format: "On-site & Online",
  price: "Custom Quote",
  originalPrice: null,
  badge: "ENTERPRISE",
  badgeColor: "bg-green-500 text-white",
  color: "from-green-500 to-emerald-500",
  description: "Tailored AI strategy course for enterprises, business leaders, managers, and corporate training needs.",
  highlights: [
  "Customized AI strategy workshops for executives",
  "Department-specific AI implementation training",
  "Change management and adoption frameworks",
  "Ongoing support and consultation"],

  link: createPageUrl("corporate-ai-workshops"),
  icon: Target
}];


const targetAudience = [
{
  icon: Crown,
  title: "Founders & CEOs",
  description: "Scale startups with AI-powered marketing strategies and operational efficiency"
},
{
  icon: TrendingUp,
  title: "CMOs & Marketing Directors",
  description: "Drive innovation and lead marketing transformation across your organization"
},
{
  icon: BarChart3,
  title: "Heads of Growth",
  description: "Build AI-powered funnels and optimization systems for sustainable growth"
},
{
  icon: Building,
  title: "Business Owners",
  description: "Implement AI tools for competitive advantage and operational excellence"
}];


const professionalApplications = [
{
  icon: TrendingUp,
  title: "For Marketers",
  description: "Automate campaign analysis, generate high-converting copy, and build AI-powered marketing funnels to maximize ROI."
},
{
  icon: UserCheck,
  title: "For Job Seekers",
  description: "Enhance your resume, automate job searches, and master AI interview tools to land your dream job faster."
},
{
  icon: Crown,
  title: "For Executives",
  description: "Leverage AI for strategic decision-making, team productivity, and forecasting to gain a competitive edge."
},
{
  icon: Rocket,
  title: "For Entrepreneurs",
  description: "Scale your business with AI-driven operations, sales automation, and customer service solutions."
},
{
  icon: Briefcase,
  title: "For Freelancers",
  description: "Boost your productivity, deliver higher quality work, and expand your service offerings with AI tools."
},
{
  icon: Users,
  title: "For HR & Finance",
  description: "Streamline recruitment, automate financial reporting, and use predictive analytics for talent and budget management."
},
{
  icon: Eye,
  title: "For Consultants",
  description: "Provide data-driven insights, automate report generation, and deliver more value to your clients with AI."
},
{
  icon: BarChart3,
  title: "For Analysts",
  description: "Automate data collection, perform complex analysis in seconds, and generate insightful reports effortlessly."
}];


const comprehensiveModules = [
{ level: 'Basic', title: "AI Fundamentals & Prompting", description: "Master ChatGPT and 15+ other AI tools to build a solid foundation for practical application in any professional role.", icon: Brain },
{ level: 'Basic', title: "AI for Data Analysis", description: "Turn raw data into actionable insights. Use AI to analyze spreadsheets, create charts, and forecast trends without complex formulas.", icon: BarChart3 },
{ level: 'Basic', title: "AI for Content Creation", description: "Generate high-quality copy, blog posts, social media updates, and creative content in a fraction of the time.", icon: Zap },
{ level: 'Intermediate', title: "AI-Powered Presentations", description: "Build compelling PowerPoint and Google Slides presentations 10x faster, from outline to final design.", icon: Eye },
{ level: 'Intermediate', title: "AI for Career Growth", description: "Accelerate your job hunt or build a powerful personal brand. Use AI to optimize your resume, LinkedIn, and networking.", icon: TrendingUp },
{ level: 'Intermediate', title: "Elevate Reading & Research", description: "Consume and synthesize information instantly. Use AI to summarize long articles, research papers, and books in seconds.", icon: Brain },
{ level: 'Intermediate', title: "Supercharge Email Productivity", description: "Master your inbox with AI. Write effective emails, achieve inbox zero, and automate follow-ups effortlessly.", icon: Zap },
{ level: 'Intermediate', title: "AI Audio & Video Creation", description: "Explore the cutting edge of AI content. Create professional voiceovers, edit videos with text commands, and generate AI avatars.", icon: Eye },
{ level: 'Advanced', title: "Workflow Automation & AI Agents", description: "Build custom AI agents and automated workflows. Connect AI tools to streamline repetitive tasks and create intelligent business processes.", icon: Settings },
{ level: 'Advanced', title: "API Integrations & Custom Solutions", description: "Connect AI models through APIs to create custom business solutions without coding knowledge.", icon: Code },
{ level: 'Advanced', title: "AI-Powered Analytics & Insights", description: "Build predictive models and advanced analytics dashboards using AI for strategic decision-making.", icon: BarChart3 },
{ level: 'Advanced', title: "AI Ethics & Governance Frameworks", description: "Implement responsible AI practices and governance frameworks for enterprise-level deployment.", icon: Shield },
{ level: 'Advanced', title: "Multi-Language AI Applications", description: "Deploy AI solutions across different languages and cultural contexts for global business operations.", icon: Languages },
{ level: 'Advanced', title: "AI-Driven Business Strategy", description: "Develop comprehensive AI transformation strategies that align with business goals and drive competitive advantage.", icon: Target },
{ level: 'Advanced', title: "Advanced AI System Architecture", description: "Design and implement complex AI ecosystems that integrate multiple tools and workflows for maximum efficiency.", icon: Rocket }];


const clientLogos = [
{ src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f2b001de0_5.png", alt: "Google" },
{ src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a110c098b_18.png", alt: "TikTok" },
{ src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/ebba4f908_24.png", alt: "Dubai Tourism" },
{ src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d1e13dbdc_3.png", alt: "Emirates" },
{ src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/1f7695b87_13.png", alt: "Alshaya" },
{ src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/c2a949770_22.png", alt: "Unilever" },
{ src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d825d99f2_6.png", alt: "Etihad" },
{ src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/da941e9d4_7.png", alt: "Harvard Business School" }];


const faqData = {
  'Course Details': [
  {
    q: "What makes this different from other AI courses?",
    a: "Our AI strategy courses focus on practical business applications, not technical theory. You'll learn Generative AI tools and AI workflow automation that you can implement immediately in your role as an executive, manager, or consultant."
  },
  {
    q: "Do I need any technical background?",
    a: "No. These AI for business courses are designed for executives, managers, and business professionals. No coding or technical knowledge required - we focus on AI for productivity and business growth."
  },
  {
    q: "What AI tools will I learn?",
    a: "You'll master ChatGPT, Claude, and 15+ other Generative AI tools for content creation, data analysis, AI automation, and business strategy. Perfect for AI generalists who want comprehensive skills."
  },
  {
    q: "Is this suitable for different industries?",
    a: "Yes. Our curriculum covers AI for CMOs, AI for growth marketing, AI for corporate training, AI for consultants, and AI for entrepreneurs across all industries."
  },
  {
    q: "What's the time commitment?",
    a: "The 3-hour mastermind requires minimal time investment. Level 1 Foundation is 15 hours over 5 days. Level 2 Accelerator is 30 hours with flexible scheduling for busy executives."
  }],

  'Logistics & Support': [
  {
    q: "How are the sessions delivered?",
    a: "All sessions are delivered live online via Zoom for maximum interactivity. This AI for executives format allows global participation while maintaining engagement."
  },
  {
    q: "What if I can't attend a live session?",
    a: "You can reschedule to another cohort if you notify us in advance. We don't provide recordings as our AI for business leaders approach emphasizes live interaction and real-time Q&A."
  },
  {
    q: "Is there ongoing support after the course?",
    a: "Yes. Level 1 and Level 2 participants get lifetime access to our private community for continued learning and networking with other AI professionals."
  },
  {
    q: "Can I retake the course?",
    a: "Yes, graduates can re-attend the same course for 25% discount within 12 months, subject to availability. This allows you to refresh your skills in the fast-evolving field of AI."
  },
  {
    q: "Do you provide recordings?",
    a: "No, we don't provide session recordings. Our AI strategy course methodology focuses on live participation, hands-on exercises, and real-time interaction for optimal learning outcomes."
  }],

  'Certificates & Outcomes': [
  {
    q: "Will I receive a certificate?",
    a: "Yes, all participants receive a Certificate of Completion for their AI in business course. This validates your expertise in Generative AI and AI workflow automation for professional development."
  },
  {
    q: "Do you provide job placement or internship opportunities?",
    a: "No, we don't provide job placement or internship services. However, our AI for managers and AI for business leaders training significantly enhances your marketability and career prospects."
  },
  {
    q: "What outcomes can I expect?",
    a: "Graduates typically see 40-60% productivity improvements, enhanced strategic thinking capabilities, and positioning as AI leaders in their organizations through practical AI automation skills."
  },
  {
    q: "Is this recognized by employers?",
    a: "Yes, our programs are highly valued by employers seeking professionals with practical Generative AI skills and AI for productivity expertise."
  }],

  'Pricing & Policies': [
  {
    q: "What's your refund policy?",
    a: "We have a no-refund policy on all courses. However, you can transfer your enrollment to a future cohort or to another person with advance notice."
  },
  {
    q: "Can I transfer my enrollment?",
    a: "Yes, you can transfer your seat to another person or reschedule to a future cohort with at least 48 hours notice before the course starts."
  },
  {
    q: "Do you offer corporate discounts?",
    a: "Yes, we offer special pricing for AI for corporate training programs and group enrollments of 5 or more participants. Contact us for customized AI strategy course packages."
  },
  {
    q: "Are there payment plans available?",
    a: "Currently, we require full payment at enrollment. However, corporate clients can arrange invoicing for our AI for executives and AI for business leaders programs."
  }]

};

const ROICalculator = () => {
  const [teamSize, setTeamSize] = useState(10);
  const [monthlySalary, setMonthlySalary] = useState(5000);

  const hoursSaved = teamSize * 5 * 52; // 5 hours per week per employee
  const annualROI = Math.round(hoursSaved * (monthlySalary / 160) * 0.8); // Assuming 160 working hours per month

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 shadow-xl">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center text-gray-900">Calculate Your AI ROI</CardTitle>
        <p className="text-center text-gray-600">Estimate potential savings from AI automation for your organization</p>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Team Size</label>
            <input
              type="range"
              min="5"
              max="100"
              value={teamSize}
              onChange={(e) => setTeamSize(parseInt(e.target.value))}
              className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer" />

            <div className="text-center text-2xl font-bold text-blue-600 mt-2">{teamSize}</div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Average Monthly Salary (USD)</label>
            <input
              type="range"
              min="2000"
              max="20000"
              step="500"
              value={monthlySalary}
              onChange={(e) => setMonthlySalary(parseInt(e.target.value))}
              className="w-full h-2 bg-blue-200 rounded-lg appearance-none cursor-pointer" />

            <div className="text-center text-2xl font-bold text-blue-600 mt-2">${monthlySalary.toLocaleString()}</div>
          </div>

          <div className="bg-white rounded-xl p-6 text-center shadow-lg">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Estimated Annual ROI from AI Workflow Automation</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-3xl font-bold text-green-600">{hoursSaved.toLocaleString()}</div>
                <div className="text-sm text-gray-600">Hours Saved</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-600">${annualROI.toLocaleString()}</div>
                <div className="text-sm text-gray-600">Productivity Gain</div>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-4">*Estimates based on 5 hours saved per employee per week through AI automation</p>
          </div>
        </div>
      </CardContent>
    </Card>);

};

const LeadMagnet = () => {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-600 to-indigo-600 text-white">
      <div className="max-w-4xl mx-auto text-center">
        <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 sm:p-12 border border-white/20">
          <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-2xl w-20 h-20 flex items-center justify-center mx-auto mb-8 shadow-lg">
            <Download className="w-10 h-10 text-gray-900" />
          </div>

          <h2 className="text-3xl sm:text-4xl font-bold mb-6">
            Get Your Free Generative AI Toolkit
          </h2>

          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto leading-relaxed">
            Download "25 High-Converting AI Prompts for Business" - the same templates our graduates use for AI workflow automation, content creation, and business strategy.
          </p>

          {!isSubmitted ?
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto mb-8">
              <input
              type="email"
              placeholder="Enter your business email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="flex-1 px-4 py-3 rounded-lg text-gray-900 placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-yellow-400" />

              <Button
              type="submit"
              className="bg-yellow-400 hover:bg-yellow-300 text-gray-900 px-8 py-3 font-bold whitespace-nowrap rounded-lg">

                <Download className="w-4 h-4 mr-2" />
                Get Free Kit
              </Button>
            </form> :

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-center justify-center gap-3 text-green-300 mb-8 bg-green-600/20 p-6 rounded-xl border border-green-400/30">

              <CheckCircle2 className="w-6 h-6" />
              <span className="text-lg font-semibold">Check your email for the AI toolkit download link!</span>
            </motion.div>
          }

          <div className="flex flex-wrap justify-center items-center gap-6 text-sm">
            <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span>Instant Download</span>
            </div>
            <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full">
              <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
              <span>No Spam Policy</span>
            </div>
            <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full">
              <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
              <span>9,000+ Downloads</span>
            </div>
          </div>
        </div>
      </div>
    </section>);

};

export default function AICourses() {
  const [activeFAQCategory, setActiveFAQCategory] = useState('Course Details');
  const [openFAQ, setOpenFAQ] = useState(0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Hero Section */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-900 via-blue-900 to-indigo-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Hero Content */}
            <div className="text-center lg:text-left">
              <Badge className="px-6 py-3 text-base font-semibold bg-white/20 text-white border border-white/30 mb-6">
                <BrainCircuit className="w-5 h-5 mr-2" />
                AI Training Programs
              </Badge>
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
                Master Generative AI for
                <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent block mt-2">
                  Business Growth
                </span>
              </h1>
              <p className="text-xl text-blue-100 max-w-4xl mx-auto lg:mx-0 leading-relaxed mb-8">
                From AI productivity foundations to building custom AI automation systems -
                choose the perfect AI strategy course to transform your career and business with Generative AI.
              </p>

              <div className="flex flex-wrap justify-center lg:justify-start gap-8 text-sm">
                <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full backdrop-blur-sm">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span>9,000+ Professionals Trained</span>
                </div>
                <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full backdrop-blur-sm">
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                  <span>300+ Enterprise Clients</span>
                </div>
                <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full backdrop-blur-sm">
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                  <span>4.9/5 Average Rating</span>
                </div>
              </div>
            </div>

            {/* Hero Image */}
            <div className="relative hidden lg:block">
              <div className="relative">
                <div className="w-full aspect-[4/3] bg-gradient-to-br from-blue-100/20 to-purple-100/20 rounded-3xl shadow-2xl overflow-hidden backdrop-blur-sm border border-white/20">
                  <img
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/dbd194a74_TheAIRevolution.jpeg"
                    alt="The AI Revolution in Business Training"
                    className="w-full h-full object-cover"
                    loading="eager"
                    decoding="async" />

                </div>
                {/* Floating elements */}
                <div className="absolute top-8 -right-8 w-32 h-32 bg-blue-400/20 rounded-full blur-3xl animate-pulse"></div>
                <div className="absolute -bottom-8 -left-8 w-40 h-40 bg-purple-400/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Executive Level Training */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="px-6 py-3 text-base font-semibold bg-blue-100 text-blue-700 border border-blue-200 mb-6 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-colors">
              <Crown className="w-5 h-5 mr-2" />
              Executive-Level Training
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Designed for Decision-Makers
            </h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed mb-12">
              This isn't for developers. It's for strategic leaders who want to harness Generative AI for business growth,
              operational efficiency, and market leadership. Perfect AI for executives and AI for business leaders programs.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="text-center border border-blue-200 shadow-lg">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">100% No-Code Required</h3>
                <p className="text-gray-600">
                  You don't need to be a programmer, data scientist, or have any technical background.
                  Our AI for managers courses are designed for business professionals who want to leverage Generative AI tools through user-friendly interfaces and strategic implementation.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border border-purple-200 shadow-lg">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Briefcase className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Business-Focused</h3>
                <p className="text-gray-600">
                  Learn practical applications that directly impact your marketing ROI and business growth through AI workflow automation.
                  Start implementing AI for productivity solutions in your work from day one.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border border-orange-200 shadow-lg">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Zap className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold mb-4">Immediate Results</h3>
                <p className="text-gray-600">
                  Zero coding skills required. We use point-and-click AI automation tools that anyone can master.
                  No technical setup required for our AI generalist approach.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {targetAudience.map((audience, index) =>
            <Card key={index} className="border border-gray-200 hover:border-blue-300 transition-all duration-300 hover:shadow-lg">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mb-4">
                    <audience.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">{audience.title}</h3>
                  <p className="text-gray-600 text-sm">{audience.description}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* What You'll Achieve */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="px-6 py-3 text-base font-semibold bg-green-100 text-green-700 border border-green-200 mb-6 hover:bg-green-600 hover:text-white hover:border-green-600 transition-colors">
              <Target className="w-5 h-5 mr-2" />
              Professional Applications
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              What You'll Achieve
            </h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto">
              AI Skills for Every Professional. Our AI in business courses are designed to equip professionals from all fields
              with practical Generative AI skills to boost productivity, drive innovation, and advance their careers through AI automation.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {professionalApplications.map((application, index) =>
            <Card key={index} className="border border-gray-200 hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center mb-4">
                    <application.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">{application.title}</h3>
                  <p className="text-gray-600 text-sm">{application.description}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Comprehensive Curriculum */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="px-6 py-3 text-base font-semibold bg-purple-100 text-purple-700 border border-purple-200 mb-6 hover:bg-purple-600 hover:text-white hover:border-purple-600 transition-colors">
              <Brain className="w-5 h-5 mr-2" />
              Comprehensive AI Curriculum
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Complete AI Mastery Path
            </h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto">
              From foundational skills to advanced system architecture, master every aspect of Generative AI implementation for business growth.
              Our AI strategy courses cover everything from AI for productivity to advanced AI workflow automation.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {comprehensiveModules.map((module, index) =>
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.5, delay: index * 0.05 }}>

                <Card className="h-full hover:shadow-xl transition-all duration-300 group border-2 relative">
                  <Badge className={`absolute top-4 right-4 font-bold ${
                module.level === 'Basic' ? 'bg-green-100 text-green-800' :
                module.level === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
                'bg-red-100 text-red-800'}`
                }>{module.level}</Badge>
                  <CardContent className="p-8 pt-12">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mb-4">
                      <module.icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-3">{module.title}</h3>
                    <p className="text-gray-600 text-sm leading-relaxed">{module.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* ROI Calculator */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Unlock Your Team's AI Potential
            </h2>
            <p className="text-xl text-gray-600">
              Use our interactive calculator to estimate the potential time and cost savings your organization
              could achieve by implementing the AI workflow automation frameworks taught in our AI for corporate training programs.
            </p>
          </div>
          <ROICalculator />
        </div>
      </section>

      {/* Course Cards */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Choose Your AI Learning Path
            </h2>
            <p className="text-gray-600 mx-auto text-lg max-w-3xl">Whether you're starting your Generative AI journey or looking to build advanced AI automation systems, we have the right AI strategy course to accelerate your growth.


            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {courses.map((course, index) =>
            <Card key={course.id} className="relative border border-gray-200 shadow-xl hover:shadow-2xl transition-all duration-300 group overflow-hidden">
                {course.badge &&
              <div className={`absolute top-4 right-4 ${course.badgeColor} px-3 py-1 rounded-full text-xs font-bold z-10`}>
                    {course.badge}
                  </div>
              }

                <CardHeader className={`bg-gradient-to-r ${course.color} text-white pb-8 pt-8`}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <Badge className="bg-white/20 text-white px-3 py-1 mb-4 text-sm font-semibold">
                        {course.level}
                      </Badge>
                      <CardTitle className="text-2xl md:text-3xl font-bold mb-2">
                        {course.title}
                      </CardTitle>
                      <p className="text-lg opacity-90 mb-4">
                        {course.subtitle}
                      </p>
                    </div>
                    <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center ml-4">
                      <course.icon className="w-8 h-8 text-white" />
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-4 text-sm">
                    <div className="flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full">
                      <Clock className="w-4 h-4" />
                      <span>{course.duration}</span>
                    </div>
                    <div className="flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full">
                      <Users className="w-4 h-4" />
                      <span>{course.format}</span>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="p-8">
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {course.description}
                  </p>

                  <div className="space-y-3 mb-8">
                    {course.highlights.map((highlight, idx) =>
                  <div key={idx} className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-700 text-sm">{highlight}</span>
                      </div>
                  )}
                  </div>

                  <div className="flex items-center justify-between mb-6">
                    <div>
                      {course.originalPrice &&
                    <span className="text-lg text-gray-500 line-through mr-2">
                          {course.originalPrice}
                        </span>
                    }
                      <span className="text-3xl font-bold text-gray-900">
                        {course.price}
                      </span>
                      {course.id === 'mastermind' &&
                    <Badge className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-1">
                          Save $151
                        </Badge>
                    }
                       {course.id === 'foundation' &&
                    <Badge className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-1">
                          Save $350
                        </Badge>
                    }
                       {course.id === 'accelerator' &&
                    <Badge className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-1">
                          Save $700
                        </Badge>
                    }
                    </div>
                  </div>

                  <Link to={course.link}>
                    <Button className={`w-full bg-gradient-to-r ${course.color} hover:opacity-90 text-white px-6 py-4 text-lg font-semibold rounded-xl shadow-lg group-hover:shadow-xl transition-all duration-300`}>
                      {course.id === 'corporate' ? 'Get Custom Quote' : 'Enroll Now'}
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* World-Class Instruction - Trainer Section Updated */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="px-6 py-3 text-base font-semibold bg-blue-100 text-blue-700 border border-blue-200 mb-6 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300">
              <Award className="w-5 h-5 mr-2" />
              World-Class Instruction
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Meet Your Expert Trainer
            </h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/5bb702e8b_Gaurav_SiFi.png"
                alt="Gaurav Oberoi - Expert AI marketing trainer"
                className="w-full h-auto rounded-2xl shadow-2xl" />

              <div className="absolute -top-4 -right-4 bg-yellow-400 text-gray-900 px-4 py-2 rounded-full font-bold text-sm">
                15+ Years Experience
              </div>
            </div>

            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">
                Gaurav Oberoi
              </h3>
              <p className="text-xl text-blue-600 font-semibold mb-6">
                Founder & Lead AI Trainer at Inc Academy
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Trained 9,000+ professionals across the GCC</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Former Google Regional Trainer</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Dubai Tourism consultant for Expo 2020</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">TikTok MENA collaborator</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Active investor & startup advisor</span>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-indigo-100">
                <h4 className="text-lg font-bold text-gray-900 mb-3">Why Learn from Gaurav?</h4>
                <p className="text-gray-600 mb-4">
                  "I've been training professionals for over 15 years, and I've never seen a technology
                  as transformative as AI. But here's the thing - it's not about the technology itself.
                  It's about how you apply it to solve real business problems. That's what I'll teach you."
                </p>
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
                  </div>
                  <span className="text-sm text-gray-500">4.9/5</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Client Logos */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-8">
              Trusted by Leading Organizations
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Join professionals from world-class companies who have transformed their careers through our AI for executives and AI for business leaders programs.
            </p>
          </div>
          <div className="bg-white rounded-2xl shadow-xl p-8 sm:p-12">
            <div className="grid grid-cols-4 md:grid-cols-8 gap-8 items-center justify-items-center">
              {clientLogos.map((client, index) =>
              <img
                key={index}
                src={client.src}
                alt={client.alt}
                className="max-h-12 w-auto opacity-60 hover:opacity-100 transition-opacity grayscale hover:grayscale-0" />

              )}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="px-6 py-3 text-base font-semibold bg-gray-100 text-gray-700 border border-gray-200 mb-6 hover:bg-gray-600 hover:text-white hover:border-gray-600 transition-colors">
              <Lightbulb className="w-5 h-5 mr-2" />
              Frequently Asked Questions
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Everything You Need to Know
            </h2>
            <p className="text-xl text-gray-600">
              Get answers about our AI for executives, AI for business leaders, and AI strategy courses.
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {Object.keys(faqData).map((category) =>
            <Button
              key={category}
              variant={activeFAQCategory === category ? 'default' : 'outline'}
              onClick={() => {
                setActiveFAQCategory(category);
                setOpenFAQ(0);
              }}
              className={`rounded-full transition-all duration-300 ${
              activeFAQCategory === category ?
              'bg-blue-600 text-white hover:bg-blue-700 border-blue-600' :
              'bg-white text-gray-800 border-gray-300 hover:bg-gray-100'}`
              }>

                {category}
              </Button>
            )}
          </div>

          <div className="space-y-4">
            {faqData[activeFAQCategory].map((faq, index) =>
            <Card key={index} className="rounded-xl shadow-sm border-gray-200 overflow-hidden">
                <button
                className="w-full text-left p-6 hover:bg-gray-50 transition-colors duration-200"
                onClick={() => setOpenFAQ(openFAQ === index ? -1 : index)}>

                  <div className="flex justify-between items-center">
                    <h3 className="font-semibold text-lg text-gray-900 pr-4">{faq.q}</h3>
                    <div className="flex-shrink-0 bg-gray-100 rounded-full w-8 h-8 flex items-center justify-center">
                      {openFAQ === index ?
                    <ChevronUp className="w-5 h-5 text-blue-600" /> :
                    <ChevronDown className="w-5 h-5 text-gray-500" />
                    }
                    </div>
                  </div>
                </button>
                {openFAQ === index &&
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="px-6 pb-6">

                    <p className="text-gray-600 leading-relaxed border-l-2 border-blue-500 pl-4">{faq.a}</p>
                  </motion.div>
              }
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Future of Work */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-gray-900 to-blue-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            The Future of Work is Here. Are You Ready?
          </h2>
          <p className="text-xl text-blue-100 mb-8 leading-relaxed">
            Generative AI won't take your job, but a person using AI will. Our AI strategy courses are designed to make you that person—the
            indispensable expert who leads with AI automation, not follows. Secure your role in the new economy by mastering the AI workflow automation tools
            that are reshaping every industry.
          </p>
          <Link to={createPageUrl("ai-skills-mastermind")}>
            <Button size="lg" className="bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white px-8 py-4 font-semibold rounded-xl">
              Future-Proof Your Career
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Lead Magnet */}
      <LeadMagnet />

      {/* CTA Section */}
      <section className="py-12 sm:py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-gray-900 to-blue-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4 sm:mb-6 leading-tight">
            Ready to Master Generative AI for Business Growth?
          </h2>
          <p className="text-base sm:text-lg md:text-xl text-blue-100 mb-6 sm:mb-8 leading-relaxed px-2">
            Join thousands of professionals who've transformed their careers and businesses with AI automation.
            Your journey to AI generalist mastery starts here.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center max-w-2xl mx-auto">
            <Link to={createPageUrl("ai-skills-mastermind")} className="w-full sm:w-auto">
              <Button size="lg" className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold rounded-xl min-h-[48px]">
                Start with 3-Hour Mastermind
                <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 ml-2" />
              </Button>
            </Link>
            <Link to={createPageUrl("contact")} className="w-full sm:w-auto">
              <Button size="lg" variant="outline" className="w-full bg-white/10 backdrop-blur-sm text-white border-2 border-white/30 hover:bg-white hover:text-gray-900 px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold rounded-xl min-h-[48px]">
                Talk to Our Team
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>);
}