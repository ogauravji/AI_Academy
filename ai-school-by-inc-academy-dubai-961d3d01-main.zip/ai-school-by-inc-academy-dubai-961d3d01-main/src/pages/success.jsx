import React, { useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Mail, Calendar, Download, MessageSquare } from 'lucide-react';

export default function Success() {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');

  useEffect(() => {
    // Track purchase event for analytics
    if (sessionId && typeof window !== 'undefined' && window.fbq) {
      window.fbq('track', 'Purchase', { currency: "USD", value: 25.00 });
    }
  }, [sessionId]);

  return (
    <div className="bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8">
          
          <div className="text-center mb-8">
            <span className="text-5xl" role="img" aria-label="party popper">🎉</span>
            <h1 className="text-2xl font-bold text-gray-800 mt-4">Congratulations!</h1>
            <p className="text-gray-600">Your enrollment has been confirmed.</p>
          </div>

          <Card className="bg-blue-50 border-blue-200 shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-blue-800">What Happens Next?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm text-gray-700">
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                <p>You'll receive a confirmation email within 5 minutes.</p>
              </div>
              <div className="flex items-start gap-3">
                <Calendar className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                <p>Course details and Zoom link will be sent 24 hours before the session.</p>
              </div>
              <div className="flex items-start gap-3">
                <Download className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                <p>Access to bonus materials will be provided via email.</p>
              </div>
            </CardContent>
          </Card>
          
          {sessionId && (
            <div className="mt-6 bg-gray-100 rounded-lg p-4 text-center">
              <p className="text-sm font-semibold text-gray-500 tracking-wide">Transaction ID:</p>
              <p className="text-sm text-gray-800 font-mono break-all mt-1 px-2">
                {sessionId}
              </p>
            </div>
          )}

          <div className="mt-8 space-y-3">
            <Button asChild className="w-full" size="lg">
              <Link to={createPageUrl('Home')}>
                Back to Home
              </Link>
            </Button>
            <Button asChild variant="default" className="w-full bg-green-600 hover:bg-green-700 text-white" size="lg">
              <a href="https://chat.whatsapp.com/GzC5p34Z8kS4kIq7aX9Y3j" target="_blank" rel="noopener noreferrer">
                <MessageSquare className="w-5 h-5 mr-2" />
                Join WhatsApp Group
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}