import Layout from "./Layout.jsx";

import Consultancy from "./Consultancy";

import Agency from "./Agency";

import Privacy from "./Privacy";

import Terms from "./Terms";

import RefundPolicy from "./RefundPolicy";

import ai-courses from "./ai-courses";

import ai-beginners-course from "./ai-beginners-course";

import ai-advanced-course from "./ai-advanced-course";

import contact from "./contact";

import about from "./about";

import corporate-ai-workshops from "./corporate-ai-workshops";

import ai-consultants from "./ai-consultants";

import ai-implementation-agency from "./ai-implementation-agency";

import success from "./success";

import cancelled from "./cancelled";

import admin-sync from "./admin-sync";

import pay-mastermind from "./pay-mastermind";

import Home from "./Home";

import ai-skills-mastermind from "./ai-skills-mastermind";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Consultancy: Consultancy,
    
    Agency: Agency,
    
    Privacy: Privacy,
    
    Terms: Terms,
    
    RefundPolicy: RefundPolicy,
    
    ai-courses: ai-courses,
    
    ai-beginners-course: ai-beginners-course,
    
    ai-advanced-course: ai-advanced-course,
    
    contact: contact,
    
    about: about,
    
    corporate-ai-workshops: corporate-ai-workshops,
    
    ai-consultants: ai-consultants,
    
    ai-implementation-agency: ai-implementation-agency,
    
    success: success,
    
    cancelled: cancelled,
    
    admin-sync: admin-sync,
    
    pay-mastermind: pay-mastermind,
    
    Home: Home,
    
    ai-skills-mastermind: ai-skills-mastermind,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Consultancy />} />
                
                
                <Route path="/Consultancy" element={<Consultancy />} />
                
                <Route path="/Agency" element={<Agency />} />
                
                <Route path="/Privacy" element={<Privacy />} />
                
                <Route path="/Terms" element={<Terms />} />
                
                <Route path="/RefundPolicy" element={<RefundPolicy />} />
                
                <Route path="/ai-courses" element={<ai-courses />} />
                
                <Route path="/ai-beginners-course" element={<ai-beginners-course />} />
                
                <Route path="/ai-advanced-course" element={<ai-advanced-course />} />
                
                <Route path="/contact" element={<contact />} />
                
                <Route path="/about" element={<about />} />
                
                <Route path="/corporate-ai-workshops" element={<corporate-ai-workshops />} />
                
                <Route path="/ai-consultants" element={<ai-consultants />} />
                
                <Route path="/ai-implementation-agency" element={<ai-implementation-agency />} />
                
                <Route path="/success" element={<success />} />
                
                <Route path="/cancelled" element={<cancelled />} />
                
                <Route path="/admin-sync" element={<admin-sync />} />
                
                <Route path="/pay-mastermind" element={<pay-mastermind />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/ai-skills-mastermind" element={<ai-skills-mastermind />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}