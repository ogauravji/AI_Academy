
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Menu,
  X,
  Mail,
  MessageCircle,
  Linkedin,
  Instagram,
  Brain,
  Rocket,
  Zap,
  Building
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import InquiryFormModal from "@/components/common/InquiryFormModal";
import ScrollToTop from "@/components/common/ScrollToTop";

const mainNavLinks = [
  { title: "Consultancy", href: createPageUrl("ai-consultants") },
  { title: "Agency", href: createPageUrl("ai-implementation-agency") },
];

const courseComponents = [
  { title: "3 Hour AI Mastermind", href: createPageUrl("ai-skills-mastermind"), description: "AI Skills to 10x Your Career in 2025.", icon: Zap },
  { title: "Level 1: AI Foundation", href: createPageUrl("ai-beginners-course"), description: "Complete AI Training for Business Professionals.", icon: Brain },
  { title: "Level 2: AI Accelerator", href: createPageUrl("ai-advanced-course"), description: "Build Custom AI Systems & Automation.", icon: Rocket },
  { title: "Corporate AI Training", href: createPageUrl("corporate-ai-workshops"), description: "Executive Workshops & Team Transformation.", icon: Building },
];

const ListItem = React.forwardRef(({ title, href, icon: Icon, children, ...props }, ref) => {
  return (
    <li>
      <NavigationMenuLink asChild>
        <Link to={href} ref={ref} className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground" {...props}>
          <div className="flex items-center gap-3">
            {Icon && <Icon className="h-5 w-5 text-blue-600" />}
            <div className="text-sm font-bold leading-none">{title}</div>
          </div>
          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground ml-8">{children}</p>
        </Link>
      </NavigationMenuLink>
    </li>
  );
});
ListItem.displayName = "ListItem";

export default function Layout({ children }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  useEffect(() => {
    const faviconUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/ec16df938_Favicon.png";
    const links = [
      { rel: 'icon', type: 'image/png', sizes: '32x32', href: faviconUrl },
      { rel: 'icon', type: 'image/png', sizes: '16x16', href: faviconUrl },
      { rel: 'apple-touch-icon', sizes: '180x180', href: faviconUrl }
    ];

    links.forEach(linkInfo => {
      let link = document.querySelector(`link[rel='${linkInfo.rel}']`);
      if (!link) {
        link = document.createElement('link');
        link.rel = linkInfo.rel;
        document.head.appendChild(link);
      }
      link.href = linkInfo.href;
      if (linkInfo.type) link.type = linkInfo.type;
      if (linkInfo.sizes) link.sizes = linkInfo.sizes;
    });

    const gtmScript = document.createElement('script');
    gtmScript.async = true;
    gtmScript.src = 'https://www.googletagmanager.com/gtm.js?id=GTM-NW92JKNB';
    document.head.appendChild(gtmScript);

    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });

    !(function(f, b, e, v, n, t, s) {
      if (f.fbq) return;
      n = f.fbq = function() { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments); };
      if (!f._fbq) f._fbq = n;
      n.push = n; n.loaded = !0; n.version = '2.0'; n.queue = [];
      t = b.createElement(e); t.async = !0; t.src = v;
      s = b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t, s);
    })(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
    
    window.fbq('init', '572346859293829');
    window.fbq('track', 'PageView');
  }, []);

  return (
    <div className="min-h-screen bg-white font-sans">
      <ScrollToTop />
      <InquiryFormModal isOpen={isModalOpen} onClose={closeModal} title="Book Discovery Call" subtitle="Schedule a call to discuss your AI marketing needs." />

      <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NW92JKNB" height="0" width="0" style={{display: 'none', visibility: 'hidden'}} />
      </noscript>
      <noscript>
        <img height="1" width="1" style={{display: 'none'}} src="https://www.facebook.com/tr?id=572346859293829&ev=PageView&noscript=1" alt="" />
      </noscript>

      <header className="fixed top-0 w-full z-50 bg-white/90 backdrop-blur-lg border-b border-gray-200/80 shadow-sm">
        <div className="bg-[#ffffff] mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="flex justify-between items-center h-16 sm:h-20">
            <Link to={createPageUrl("Home")} className="flex items-center space-x-2 group shrink-0">
              <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68947005b6a22444961d3d01/b4844d853_Inc_Academy_Logo_Transparent.png" alt="Inc. Academy Logo" className="h-10 sm:h-12 w-auto" width="200" height="48" />
            </Link>

            <div className="hidden lg:flex items-center space-x-2">
              <NavigationMenu>
                <NavigationMenuList>
                  <NavigationMenuItem>
                    <NavigationMenuTrigger className="text-gray-700 hover:text-blue-600 font-semibold transition-colors px-3 py-2 text-base">Courses</NavigationMenuTrigger>
                    <NavigationMenuContent>
                      <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                        {courseComponents.map((component) => (
                          <ListItem key={component.title} title={component.title} href={component.href} icon={component.icon}>
                            {component.description}
                          </ListItem>
                        ))}
                      </ul>
                    </NavigationMenuContent>
                  </NavigationMenuItem>
                  {mainNavLinks.map((item) => (
                    <NavigationMenuItem key={item.title}>
                      <Link to={item.href}>
                        <NavigationMenuLink className={`${navigationMenuTriggerStyle()} text-gray-700 hover:text-blue-600 font-semibold transition-colors px-3 py-2 text-base`}>
                          {item.title}
                        </NavigationMenuLink>
                      </Link>
                    </NavigationMenuItem>
                  ))}
                </NavigationMenuList>
              </NavigationMenu>
              <Button className="bg-blue-600 text-white border-2 border-blue-600 hover:bg-white hover:text-blue-600 px-5 py-2.5 font-semibold shadow-sm hover:shadow-md transition-all duration-300 rounded-lg text-sm" onClick={openModal}>
                Book Discovery Call
              </Button>
            </div>

            <div className="lg:hidden">
              <button className="p-2 text-gray-700 hover:text-blue-600 transition-colors" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} aria-label="Toggle mobile menu">
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-t border-gray-100 shadow-md absolute top-full left-0 w-full">
            <div className="px-4 py-4 space-y-2">
              <div className="px-3 py-2 font-semibold text-gray-500 text-sm">Courses</div>
              {courseComponents.map((item) => (
                <Link key={item.title} to={item.href} onClick={() => setMobileMenuOpen(false)} className="block text-gray-700 font-semibold py-2 px-3 rounded-md hover:bg-gray-100">
                  {item.title}
                </Link>
              ))}
              <div className="border-t my-2"></div>
              {mainNavLinks.map((item) => (
                <Link key={item.title} to={item.href} onClick={() => setMobileMenuOpen(false)} className="block text-gray-700 font-semibold py-2 px-3 rounded-md hover:bg-gray-100">
                  {item.title}
                </Link>
              ))}
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold mt-2 rounded-lg py-2.5" onClick={() => { openModal(); setMobileMenuOpen(false); }}>
                Book Discovery Call
              </Button>
            </div>
          </div>
        )}
      </header>

      <main className="pt-16 sm:pt-20">
        {children}
      </main>

      <footer className="bg-gray-900 text-slate-300 relative overflow-hidden">
        <div className="relative max-w-7xl mx-auto pt-16 pb-12 px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 pb-12 border-b border-slate-800">
            <h2 className="text-3xl font-bold text-white mb-4">Ready to Lead the AI Revolution?</h2>
            <p className="text-slate-400 mb-8 max-w-2xl mx-auto">Let's discuss how our AI training, consultancy, and implementation services can future-proof your business.</p>
            <Button size="lg" className="bg-blue-600 text-white border-2 border-blue-600 hover:bg-white hover:text-blue-600 px-8 py-3 font-semibold shadow-lg hover:shadow-blue-500/20 transition-all duration-300 rounded-lg text-base" onClick={openModal}>
              Book a Free Discovery Call
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="space-y-4 lg:col-span-1 md:col-span-2">
              <Link to={createPageUrl("Home")}>
                <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68947005b6a22444961d3d01/b4844d853_Inc_Academy_Logo_Transparent.png" alt="Inc. Academy Logo" className="h-10 w-auto" />
              </Link>
              <p className="text-sm text-slate-400 leading-relaxed pr-4">
                Empowering professionals and brands to lead with Generative AI through executive training, consultancy, and done-for-you AI automation.
              </p>
            </div>

            <div className="lg:col-span-1">
              <h3 className="text-sm font-semibold tracking-wider uppercase text-white mb-4">AI Training</h3>
              <ul className="space-y-3">
                {courseComponents.map((item) => (
                  <li key={item.title}>
                    <Link to={item.href} className="text-slate-400 hover:text-white transition-colors py-1 block">
                      {item.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div className="lg:col-span-1">
              <h3 className="text-sm font-semibold tracking-wider uppercase text-white mb-4">Company</h3>
              <ul className="space-y-3">
                <li><Link to={createPageUrl("about")} className="text-slate-400 hover:text-white transition-colors py-1 block">About Us</Link></li>
                <li><Link to={createPageUrl("ai-consultants")} className="text-slate-400 hover:text-white transition-colors py-1 block">Consultancy</Link></li>
                <li><Link to={createPageUrl("ai-implementation-agency")} className="text-slate-400 hover:text-white transition-colors py-1 block">Agency</Link></li>
                <li><Link to={createPageUrl("contact")} className="text-slate-400 hover:text-white transition-colors py-1 block">Contact Us</Link></li>
              </ul>
            </div>
            
            <div className="lg:col-span-1">
              <h3 className="text-sm font-semibold tracking-wider uppercase text-white mb-4">Connect</h3>
              <a href="mailto:hello@inc.academy" className="flex items-center gap-3 group mb-4">
                <Mail className="w-5 h-5 text-slate-500 group-hover:text-blue-400 transition-colors" />
                <span className="text-slate-400 group-hover:text-white transition-colors">hello@inc.academy</span>
              </a>
              <div className="flex space-x-3">
                <a href="https://www.linkedin.com/company/incacademydubai/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-blue-600 transition-colors">
                  <Linkedin className="w-5 h-5 text-white" />
                </a>
                <a href="https://www.instagram.com/incdigitalacademy/" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-pink-600 transition-colors">
                  <Instagram className="w-5 h-5 text-white" />
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm text-slate-500 text-center md:text-left">© {new Date().getFullYear()} Inc Academy. All Rights Reserved.</p>
            <div className="flex flex-wrap justify-center md:justify-end gap-x-6 gap-y-2 text-sm">
              <Link to={createPageUrl("Privacy")} className="text-slate-500 hover:text-white transition-colors">Privacy Policy</Link>
              <Link to={createPageUrl("Terms")} className="text-slate-500 hover:text-white transition-colors">Terms & Conditions</Link>
              <Link to={createPageUrl("RefundPolicy")} className="text-slate-500 hover:text-white transition-colors">Refund Policy</Link>
            </div>
          </div>
        </div>
      </footer>

      <a href="https://wa.me/971524371377" target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp" className="fixed bottom-4 md:bottom-5 right-4 md:right-5 w-12 h-12 md:w-14 md:h-14 bg-green-500 hover:bg-green-600 hover:scale-110 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 z-50">
        <MessageCircle className="w-6 h-6 md:w-7 md:h-7 text-white" />
      </a>
    </div>
  );
}
