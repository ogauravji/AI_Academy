import React from 'react';
import AgentShowcase from '@/components/agency/AgentShowcase';

export default function Agency() {
    return (
        <div>
            <AgentShowcase />
        </div>
    );
}