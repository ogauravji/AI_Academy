
import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import StripePaymentLinkButton from '@/components/common/StripePaymentLinkButton';
import {
  Target, CheckCircle2, TrendingUp, Briefcase, Rocket, Users, Award, Star, ArrowRight,
  BrainCircuit, AlertTriangle, DollarSign, Shield, BookOpen, UserCheck, BarChart3,
  PenSquare, Building, Eye, Zap, Crown, Brain, Globe, Clock, Calendar, Monitor,
  MessageCircle, Mail, Film, Presentation, ChevronDown, ChevronUp, Flame, Download,
  Timer, Package, Percent, Code, Settings, UserMinus, UserPlus
} from "lucide-react";
import { motion } from "framer-motion";

const CountdownTimer = ({ targetDate, theme = 'dark' }) => {
  const [timeLeft, setTimeLeft] = React.useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  React.useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime();
      const distance = new Date(targetDate).getTime() - now;

      if (distance > 0) {
        setTimeLeft({
          days: Math.floor(distance / (1000 * 60 * 60 * 24)),
          hours: Math.floor(distance % (1000 * 60 * 60 * 24) / (1000 * 60 * 60)),
          minutes: Math.floor(distance % (1000 * 60 * 60) / (1000 * 60)),
          seconds: Math.floor(distance % (1000 * 60) / 1000)
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  const colors = {
    dark: {
      bg: 'bg-white/20',
      valueText: 'text-white',
      unitText: 'text-blue-200'
    },
    light: {
      bg: 'bg-gray-100',
      valueText: 'text-gray-900',
      unitText: 'text-gray-600'
    }
  };

  const selectedTheme = colors[theme];

  return (
    <div className="flex gap-2 sm:gap-4 justify-center">
      {Object.entries(timeLeft).map(([unit, value]) =>
        <div key={unit} className={`${selectedTheme.bg} backdrop-blur-sm rounded-lg p-2 sm:p-4 text-center min-w-12 sm:min-w-16`}>
          <div className={`text-lg sm:text-2xl font-bold ${selectedTheme.valueText}`}>{value.toString().padStart(2, '0')}</div>
          <div className={`text-xs ${selectedTheme.unitText} uppercase`}>{unit}</div>
        </div>
      )}
    </div>);

};

const whoShouldAttend = [
  { icon: Briefcase, title: "Marketing & Sales Professionals", description: "Automate campaigns, generate leads, and analyze data with Generative AI and AI workflow automation." },
  { icon: Users, title: "HR & Operations Managers", description: "Streamline workflows, improve recruitment, and boost team productivity through AI for productivity." },
  { icon: Crown, title: "Founders & Business Owners", description: "Implement AI automation to cut costs, scale operations, and gain a competitive edge with AI for entrepreneurs." },
  { icon: TrendingUp, title: "Consultants & Freelancers", description: "Deliver more value to clients by integrating AI for consultants and becoming an AI generalist." },
  { icon: Rocket, title: "Ambitious Career Changers", description: "Gain the most in-demand skill of the decade to pivot into a future-proof role with AI for business leaders." },
  { icon: UserCheck, title: "Any Professional Eager to Lead", description: "Anyone who wants to work smarter, not harder, and stay relevant with AI for executives training." }];


const modules = [
  { level: 'Basic', title: "AI Fundamentals & Prompting", description: "Master ChatGPT and 15+ other Generative AI tools to build a solid foundation for AI for productivity." },
  { level: 'Basic', title: "AI for Content Creation", description: "Generate high-quality copy, blog posts, and social media updates in minutes using AI automation." },
  { level: 'Basic', title: "AI for Data Analysis", description: "Turn raw data into actionable insights without complex formulas - perfect for AI for CMOs." },
  { level: 'Intermediate', title: "AI-Powered Presentations", description: "Build compelling PowerPoint and Google Slides presentations 10x faster with AI workflow automation." },
  { level: 'Intermediate', title: "Elevate Reading & Research", description: "Summarize long articles, research papers, and books in seconds using advanced Generative AI." },
  { level: 'Intermediate', title: "AI for Career Growth", description: "Optimize your resume, LinkedIn, and networking with AI for managers and business professionals." },
  { level: 'Intermediate', title: "Supercharge Email Productivity", description: "Master your inbox with AI automation. Write effective emails and automate follow-ups." },
  { level: 'Intermediate', title: "AI Audio & Video Creation", description: "Create professional voiceovers and edit videos using text commands - ideal for AI for growth marketing." }];


const testimonials = [
  { quote: "I was a complete beginner, and this course made AI accessible and exciting. I'm already saving 5-7 hours a week by automating reports. A total game-changer for my productivity.", author: "Fatima Al-Jaber", role: "Operations Manager, Retail Group" },
  { quote: "The most practical professional training I've ever taken. The hands-on modules meant I was building things from day one. I've since implemented three new AI workflows for my team.", author: "David Chen", role: "Marketing Team Lead, Tech Startup" },
  { quote: "The Level 1 foundation gave me confidence to speak AI fluently in board meetings. Within a month, I was leading our company's AI transformation initiative.", author: "Sarah Ahmed", role: "VP Strategy, Financial Services" },
  { quote: "From zero AI knowledge to automating 60% of my client reporting. This course didn't just teach tools, it taught me to think strategically about AI implementation.", author: "Michael Rodriguez", role: "Digital Marketing Consultant" }];


const industryFacts = [
  {
    icon: TrendingUp,
    title: "40% Productivity Boost",
    description: "Companies using AI report a 40% increase in productivity.",
  },
  {
    icon: DollarSign,
    title: "35% Higher Salaries",
    description: "Professionals with AI skills earn up to 35% more than their peers.",
  },
  {
    icon: Briefcase,
    title: "87% Enterprise Adoption",
    description: "The majority of enterprise companies are now actively using AI tools.",
  },
];

const bonusItems = [
  { icon: Award, title: "Digital Marketing Certification", value: "$1299", description: "Full access to our comprehensive, self-paced Professional Certification in Digital Marketing." },
  { icon: BookOpen, title: "200+ AI Prompt Library", value: "$200", description: "Proven prompts for marketing, sales, HR, and operations." },
  { icon: Code, title: "Zero-to-Website Guide", value: "$150", description: "Step-by-step guide to building a website using AI, no coding required." },
  { icon: Percent, title: "AI Tool Discount Codes", value: "$150", description: "Exclusive discounts on popular AI platforms and software." }
];

const clientLogos = [
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f2b001de0_5.png", alt: "Google" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a110c098b_18.png", alt: "TikTok" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/ebba4f908_24.png", alt: "Dubai Tourism" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d1e13dbdc_3.png", alt: "Emirates" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/1f7695b87_13.png", alt: "Alshaya" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/c2a949770_22.png", alt: "Unilever" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d825d99f2_6.png", alt: "Etihad" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/da941e9d4_7.png", alt: "Harvard Business School" }];


const faqsData = {
  'General & Suitability': [
    {
      q: "Is this course suitable for non-technical professionals?",
      a: "Yes. This AI for business course is built for executives, marketers, and managers—no coding skills required. We focus on practical AI for productivity and AI workflow automation that any professional can master."
    },
    {
      q: "I'm already using ChatGPT. Will this still be useful?",
      a: "Absolutely. You'll move beyond basic prompting to master advanced Generative AI strategies, frameworks, and tools that most users don't know, transforming you into an AI generalist with comprehensive skills."
    },
    {
      q: "Will you cover examples relevant to my industry?",
      a: "Yes. Our AI strategy course includes use cases for AI for CMOs, AI for growth marketing, AI for corporate training, AI for consultants, and AI for entrepreneurs across diverse sectors."
    }],

  'Technical & Projects': [
    {
      q: "Do I need any technical background?",
      a: "No technical background required. This AI in business course is designed specifically for business professionals, executives, and managers who want to leverage AI automation without coding."
    },
    {
      q: "What AI tools will I learn?",
      a: "You'll master ChatGPT, Claude, and 15+ other Generative AI tools for content creation, data analysis, presentations, and AI workflow automation - becoming a well-rounded AI generalist."
    },
    {
      q: "What's the time commitment?",
      a: "The course is 15 hours delivered over 5 sessions (3 hours each). Perfect for busy executives and managers who want comprehensive AI for productivity training."
    }],

  'Logistics & Support': [
    {
      q: "How will I join the session?",
      a: "You'll receive a Zoom link by email 24 hours before the session. All our AI for executives training is live and interactive for maximum engagement."
    },
    {
      q: "What if I am unable to attend a live session?",
      a: "You can reschedule to a future cohort if you notify us at least 48 hours in advance. Our AI for managers course methodology relies on live participation for optimal results."
    },
    {
      q: "Do you provide recordings of the sessions?",
      a: "No, we do not provide recordings. Our AI strategy course methodology emphasizes live, hands-on learning and real-time interaction to ensure the highest quality educational experience."
    },
    {
      q: "Is there ongoing support after the course?",
      a: "Yes! You get lifetime access to our private graduate community for ongoing Q&A, networking, and to stay updated on the latest in Generative AI and AI automation."
    },
    {
      q: "Can I retake the course?",
      a: "Yes, graduates can re-attend the same course for 25% discount within 12 months, subject to availability. This allows you to refresh your skills in the fast-evolving field of AI."
    }],

  'Outcomes & Policies': [
    {
      q: "Will I get a certificate upon completion?",
      a: "Yes, upon successful completion, you will receive a Certificate of Completion from Inc. Academy, validating your new skills in AI workflow automation and strategy."
    },
    {
      q: "Do you offer job placement or internships?",
      a: "We do not offer direct job placement or internship services. However, this AI for executives course provides you with highly in-demand skills that significantly strengthen your professional profile."
    },
    {
      q: "What's the refund policy?",
      a: "All sales are final, and we do not offer refunds. We are confident in the immense value of our AI in business course. You may, however, transfer your seat or reschedule to a future date with advance notice."
    }]

};

export default function Level1Foundation() {
  const [openFAQ, setOpenFAQ] = React.useState(0);
  const [activeFAQCategory, setActiveFAQCategory] = React.useState('General & Suitability');
  const [email, setEmail] = React.useState("");
  const [isSubmitted, setIsSubmitted] = React.useState(false);

  // Set timer to 6 days from now
  const sixDaysFromNow = new Date();
  sixDaysFromNow.setDate(sixDaysFromNow.getDate() + 6);

  React.useEffect(() => {
    const setMetaTag = (attr, attrValue, content) => {
      let element = document.querySelector(`meta[${attr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const title = "Level 1: AI Skills Foundation for Business Professionals | Inc. Academy";
    const description = "Join our 15-hour live online course on Generative AI for business. Learn AI for productivity, workflow automation, and strategy. No coding required. Perfect for executives, managers, and entrepreneurs seeking AI automation skills.";
    const imageUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f84a66173_ai.jpeg"; // Updated image URL

    document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:url', window.location.href);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);
  }, []);

  const scrollToForm = () => {
    document.getElementById('booking-section').scrollIntoView({ behavior: 'smooth' });
  };

  const handleLeadSubmit = (e) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  return (
    <div className="bg-white text-gray-800">
      {/* Hero Section */}
      <section className="relative bg-slate-900 text-white overflow-hidden">
        <div className="absolute inset-0 bg-grid-slate-100/[0.05] [mask-image:linear-gradient(to_bottom,white_5%,transparent_95%)]"></div>
        <div className="absolute inset-y-0 right-0 w-1/2 bg-gradient-to-l from-blue-900/50 to-transparent blur-3xl opacity-40"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center py-20 sm:py-32">
            {/* Text Content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center lg:text-left z-10">

              <Badge className="mb-6 bg-blue-500 text-white px-4 py-2 text-sm font-semibold hover:bg-blue-600 transition-colors">
                Level 1: AI Skills Foundation
              </Badge>
              <h1 className="text-4xl sm:text-6xl font-bold mb-6 tracking-tight">
                Master the AI Essentials. Transform Your Career.
              </h1>
              <p className="text-lg sm:text-xl text-blue-200 max-w-xl mx-auto lg:mx-0 mb-8">This is your starting point for AI mastery. A 15-hour, live online program designed to equip you with the most in-demand Generative AI skills, tools, and AI workflow automation - no coding required.

              </p>
              <div className="flex justify-center lg:justify-start">
                <Button onClick={scrollToForm} size="lg" className="bg-blue-600 text-white border-2 border-blue-600 hover:bg-white hover:text-blue-600 px-8 py-4 rounded-xl shadow-lg group text-lg transition-all duration-300">
                  Enroll in Level 1
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </motion.div>

            {/* Image Content */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden lg:flex justify-center">

              <div className="relative w-full max-w-lg">
                <div className="absolute -inset-4 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full blur-3xl opacity-50 animate-pulse"></div>
                <img
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f84a66173_ai.jpeg"
                  alt="AI brain with neural networks and circuit patterns - representing AI learning foundation"
                  className="relative rounded-2xl shadow-2xl" />

              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Timer Section */}
      <section className="py-8 bg-red-600 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h3 className="text-xl font-bold mb-4">Early Bird Pricing Ends Soon!</h3>
          <CountdownTimer targetDate={sixDaysFromNow.toISOString()} />
          <p className="text-sm mt-4 opacity-90">Don't miss out on 30% savings - Limited seats available</p>
        </div>
      </section>

      {/* Why AI Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-indigo-50 to-blue-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-indigo-100 text-indigo-800 px-6 py-3 text-base font-medium mb-6 hover:bg-indigo-600 hover:text-white hover:border-indigo-600 transition-all duration-300">
              <Brain className="w-5 h-5 mr-2" />
              The AI Revolution
            </Badge>
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-6">
              Why AI Skills Are Essential for Your Future
            </h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto">
              The job market is transforming rapidly. Those who master Generative AI and AI for productivity will lead, while those who don't will be left behind.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {industryFacts.map((fact, index) => {
              const IconComponent = fact.icon;
              return (
                <Card key={index} className="text-center border-indigo-200 bg-white">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-center mb-3">
                      {IconComponent && <IconComponent className="w-8 h-8 text-indigo-600" />}
                    </div>
                    <div className="text-xl font-bold text-gray-900 mb-2">{fact.title}</div>
                    <p className="text-gray-700 text-sm">{fact.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg border border-indigo-100">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">The Choice Is Clear</h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <span>AI-skilled professionals earn 30-50% more</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <span>Companies prioritize AI-literate candidates for promotions</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <span>AI skills are transferable across all industries</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    <span>Early adopters gain sustainable competitive advantages</span>
                  </li>
                </ul>
              </div>
              <div className="text-center">
                <img
                  src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                  alt="AI Future of Work"
                  className="w-full rounded-xl shadow-lg" />

              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Urgency Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-red-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-red-100 text-red-800 px-4 py-2 mb-6 hover:bg-red-600 hover:text-white hover:border-red-600 transition-all duration-300">
              <Flame className="w-4 h-4 mr-2" />
              Limited Time Offer
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold mb-6 text-gray-900">
              The AI Revolution is Happening Now
            </h2>
            <p className="text-lg text-gray-700 mb-8">
              Every day you delay learning AI automation is another day your competitors get ahead. Don't let this opportunity pass.
            </p>
          </div>

          <div className="text-center">
            <Button onClick={scrollToForm} size="lg" className="bg-red-600 text-white border-2 border-red-600 hover:bg-white hover:text-red-600 px-8 py-4 rounded-xl transition-all duration-300">
              Don't Get Left Behind - Enroll Now
            </Button>
          </div>
        </div>
      </section>

      {/* What You'll Learn Section */}
      <section id="modules" className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge variant="outline" className="px-6 py-3 text-base font-medium border-blue-200 text-blue-700 mb-8 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300">
              <BrainCircuit className="w-5 h-5 mr-2" />
              Your Hands-On Curriculum
            </Badge>
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-6">What You Will Master</h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto">
              Our curriculum is designed for immediate application. Each module provides practical AI for productivity skills using no-code tools perfect for AI for business leaders.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {modules.map((module, index) =>
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.5 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}>

                <Card className="h-full hover:shadow-xl transition-all duration-300 group border-2 relative">
                  <Badge className={`absolute top-4 right-4 font-bold ${
                    module.level === 'Basic' ? 'bg-green-100 text-green-800' :
                      'bg-yellow-100 text-yellow-800'}`
                  }>{module.level}</Badge>
                  <CardContent className="p-8 pt-12">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{module.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{module.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* Before & After Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-6">Your Professional Transformation</h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto">
              Go from manual processes and uncertainty to automated workflows and strategic AI for executives leadership.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <Card className="border-red-200 bg-red-50/50 p-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-red-500 text-white rounded-full flex items-center justify-center">
                  <UserMinus className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold text-red-800">Before This Course</h3>
              </div>
              <ul className="space-y-3 text-red-900">
                <li className="flex items-start gap-3"><AlertTriangle className="w-5 h-5 text-red-400 mt-1" /><span>Overwhelmed by manual, repetitive tasks eating up valuable time.</span></li>
                <li className="flex items-start gap-3"><AlertTriangle className="w-5 h-5 text-red-400 mt-1" /><span>Unsure how to apply Generative AI to your specific role and industry.</span></li>
                <li className="flex items-start gap-3"><AlertTriangle className="w-5 h-5 text-red-400 mt-1" /><span>Falling behind competitors who are adopting AI automation.</span></li>
                <li className="flex items-start gap-3"><AlertTriangle className="w-5 h-5 text-red-400 mt-1" /><span>Struggling to generate creative ideas and high-quality content consistently.</span></li>
                <li className="flex items-start gap-3"><AlertTriangle className="w-5 h-5 text-red-400 mt-1" /><span>Missing out on AI for productivity opportunities in daily work.</span></li>
              </ul>
            </Card>
            <Card className="border-green-200 bg-green-50/50 p-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-green-500 text-white rounded-full flex items-center justify-center">
                  <UserPlus className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold text-green-800">After This Course</h3>
              </div>
              <ul className="space-y-3 text-green-900">
                <li className="flex items-start gap-3"><CheckCircle2 className="w-5 h-5 text-green-500 mt-1" /><span>Automating 5-10 hours of work per week with AI workflow automation.</span></li>
                <li className="flex items-start gap-3"><CheckCircle2 className="w-5 h-5 text-green-500 mt-1" /><span>Confidently implementing AI for business leaders strategies and tools.</span></li>
                <li className="flex items-start gap-3"><CheckCircle2 className="w-5 h-5 text-green-500 mt-1" /><span>Leading AI adoption within your team and company as an AI generalist.</span></li>
                <li className="flex items-start gap-3"><CheckCircle2 className="w-5 h-5 text-green-500 mt-1" /><span>Becoming a go-to AI for managers strategist in your organization.</span></li>
                <li className="flex items-start gap-3"><CheckCircle2 className="w-5 h-5 text-green-500 mt-1" /><span>Mastering AI for growth marketing and AI for corporate training applications.</span></li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* Who Should Attend Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-6">Designed For Every Ambitious Professional</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">This AI Skills Foundation course is for anyone ready to leverage AI for productivity and massive career growth in the AI in business landscape.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {whoShouldAttend.map((audience, index) =>
              <Card key={index} className="border-gray-200 hover:border-blue-300 transition-all duration-300 hover:shadow-lg">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mb-4">
                    <audience.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{audience.title}</h3>
                  <p className="text-gray-600">{audience.description}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Trainer Section - Updated */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-white relative overflow-hidden">
        <div className="absolute top-0 left-0 -translate-x-1/4 -translate-y-1/4 w-96 h-96 bg-blue-50 rounded-full blur-3xl opacity-70"></div>
        <div className="absolute bottom-0 right-0 translate-x-1/4 translate-y-1/4 w-96 h-96 bg-purple-50 rounded-full blur-3xl opacity-70"></div>

        <div className="max-w-7xl mx-auto relative">
          <div className="text-center mb-16">
            <Badge className="bg-blue-100 text-blue-800 px-6 py-3 text-base font-medium mb-6 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300">
              <Award className="w-5 h-5 mr-2" />
              Your Expert Instructor
            </Badge>
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900">Learn from a Proven Industry Leader</h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/5bb702e8b_Gaurav_SiFi.png"
                alt="Gaurav Oberoi - Expert AI marketing trainer"
                className="w-full h-auto rounded-2xl shadow-2xl" />

              <div className="absolute -top-4 -right-4 bg-yellow-400 text-gray-900 px-4 py-2 rounded-full font-bold text-sm">
                15+ Years Experience
              </div>
            </div>

            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">
                Gaurav Oberoi
              </h3>
              <p className="text-xl text-blue-600 font-semibold mb-6">
                Founder & Lead AI Trainer at Inc Academy
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Trained 9,000+ professionals across the GCC</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Former Google Regional Trainer</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Dubai Tourism consultant for Expo 2020</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">TikTok MENA collaborator</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Active investor & startup advisor</span>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-indigo-100">
                <h4 className="text-lg font-bold text-gray-900 mb-3">Why Learn from Gaurav?</h4>
                <p className="text-gray-600 mb-4">
                  "I've been training professionals for over 15 years, and I've never seen a technology
                  as transformative as Generative AI. But here's the thing - it's not about the technology itself.
                  It's about how you apply it to solve real business problems. That's what I'll teach you in this AI for executives program."
                </p>
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
                  </div>
                  <span className="text-sm text-gray-500">4.9/5</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Client Logos Section */}
      <section className="bg-white pt-0 pb-16 sm:pb-20 -mt-12 md:-mt-16 relative z-10">
        <div className="mx-auto max-w-5xl px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-xl p-8 sm:p-12">
            <h2 className="text-center text-lg font-semibold text-gray-600 mb-8">
              Trusted by Professionals From Leading Global Brands
            </h2>
            <div className="mx-auto grid max-w-lg grid-cols-4 items-center gap-x-8 gap-y-10 sm:max-w-xl sm:grid-cols-6 sm:gap-x-10 lg:mx-0 lg:max-w-none lg:grid-cols-8">
              {clientLogos.map((client, index) =>
                <img
                  key={index}
                  className="col-span-2 max-h-12 w-full object-contain lg:col-span-1 opacity-70 hover:opacity-100 transition-opacity"
                  src={client.src}
                  alt={client.alt}
                  width="158"
                  height="48"
                  loading="lazy"
                  decoding="async" />

              )}
            </div>
          </div>
        </div>
      </section>

      {/* Bonus Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-yellow-100 text-yellow-800 px-6 py-3 text-base font-semibold mb-6 hover:bg-yellow-600 hover:text-white hover:border-yellow-600 transition-all duration-300">
              <Award className="w-5 h-5 mr-2" />
              Exclusive Bonus Package
            </Badge>
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-6">
              Get Over $1750 Worth of Bonuses, Free!
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              These exclusive resources are included with your enrollment to accelerate your AI for productivity journey.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {bonusItems.map((bonus, index) => (
              <Card key={index} className="text-center border-yellow-200 hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-yellow-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <bonus.icon className="w-8 h-8 text-yellow-600" />
                  </div>
                  <h4 className="font-bold text-lg mb-2">{bonus.title}</h4>
                  <div className="text-2xl font-bold text-yellow-600 mb-2">{bonus.value}</div>
                  <p className="text-gray-600 text-sm">{bonus.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <Button onClick={scrollToForm} size="lg" className="bg-yellow-500 text-gray-900 border-2 border-yellow-500 hover:bg-white hover:text-yellow-600 px-8 py-4 rounded-xl font-bold transition-all duration-300">
              Claim My $1750+ Bonus Pack
            </Button>
          </div>
        </div>
      </section>

      {/* Booking & Details Section - MOBILE FRIENDLY REVISION */}
      <section id="booking-section" className="py-16 sm:py-24 px-4 sm:px-6 lg:px-8 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 md:gap-16 items-center">
            {/* Left Column: Details */}
            <div className="space-y-8 text-center lg:text-left">
              <h2 className="text-3xl sm:text-4xl font-bold">Ready to Build Your AI Foundation?</h2>
              <p className="text-lg sm:text-xl text-blue-200">
                Secure your seat in our next live, instructor-led cohort. All sessions are delivered online via Zoom for an interactive AI for business leaders experience.
              </p>
              <div className="space-y-4 text-base sm:text-lg inline-block text-left lg:inline-grid">
                <div className="flex items-center gap-3 sm:gap-4"><Calendar className="w-6 h-6 text-blue-400 flex-shrink-0" /> <span><strong>Next Cohort:</strong> August 26 - 31, 2024</span></div>
                <div className="flex items-center gap-3 sm:gap-4"><Clock className="w-6 h-6 text-blue-400 flex-shrink-0" /> <span><strong>Time:</strong> 7pm - 10pm Dubai Time (GMT+4)</span></div>
                <div className="flex items-center gap-3 sm:gap-4"><Monitor className="w-6 h-6 text-blue-400 flex-shrink-0" /> <span><strong>Mode:</strong> Live Online via Zoom</span></div>
              </div>
              <div className="bg-white/10 p-6 sm:p-8 rounded-2xl border border-blue-800">
                <h3 className="font-bold text-lg sm:text-xl mb-4">What's Included:</h3>
                <ul className="space-y-3 text-blue-200 text-sm sm:text-base text-left">
                  <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-green-400 mt-0.5 shrink-0" /><span>15 hours of live, expert-led AI strategy course training</span></li>
                  <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-green-400 mt-0.5 shrink-0" /><span>Access to 200+ Generative AI prompt library</span></li>
                  <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-green-400 mt-0.5 shrink-0" /><span>Lifetime access to private WhatsApp community</span></li>
                  <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-green-400 mt-0.5 shrink-0" /><span>Certificate of Completion</span></li>
                </ul>
              </div>
            </div>

            {/* Right Column: Payment Card */}
            <div className="relative mt-8 lg:mt-0 max-w-md lg:max-w-none mx-auto w-full">
              <div className="absolute top-2 right-2 sm:top-0 sm:right-0 bg-red-600 text-white px-3 py-1 sm:px-4 sm:py-2 rounded-full text-xs sm:text-sm font-bold transform rotate-12 shadow-lg z-30">
                <Flame className="w-3 h-3 sm:w-4 sm:h-4 inline mr-1" />
                HURRY!
              </div>

              <Card className="bg-gradient-to-br from-white to-gray-50 text-gray-800 p-6 sm:p-8 shadow-2xl border-4 border-red-200 relative">
                <div className="bg-red-50 border-l-4 border-red-400 p-3 sm:p-4 mb-6 rounded-r-lg">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" />
                    <p className="text-red-700 font-semibold text-xs sm:text-sm">Limited spots left in this cohort!</p>
                  </div>
                </div>

                <h3 className="text-xl sm:text-2xl font-bold text-center mb-2">⏰ Early Bird Ends Soon</h3>
                <p className="text-center text-gray-600 mb-6 text-sm sm:text-base">Don't miss your chance to save 30%</p>

                <div className="text-center mb-6">
                  <p className="text-base sm:text-lg text-gray-500 line-through mb-1">Regular Price: $1,250</p>
                  <div className="bg-red-600 text-white px-4 py-2 rounded-lg inline-block mb-2">
                    <p className="text-3xl sm:text-4xl font-extrabold">$900</p>
                  </div>
                  <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full inline-block text-xs sm:text-sm font-bold">
                    💰 Save $350 Today!
                  </div>
                </div>

                <div className="bg-gray-100 p-3 sm:p-4 rounded-lg mb-6">
                  <p className="text-center text-xs sm:text-sm font-semibold text-gray-700 mb-2">Early Bird Expires In:</p>
                  <CountdownTimer targetDate={sixDaysFromNow.toISOString()} theme="light" />
                </div>

                <StripePaymentLinkButton
                  href="https://buy.stripe.com/14k7tYc9j7oE28E9AC"
                  className="w-full bg-red-600 text-white border-2 border-red-600 hover:bg-white hover:text-red-600 py-3 sm:py-4 text-base sm:text-lg font-bold rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200">
                  🚀 Secure My Seat Now
                </StripePaymentLinkButton>

                <div className="mt-4 text-center space-y-2">
                  <p className="text-xs text-gray-500">
                    ✅ Secure payment via Stripe • 🔒 SSL encrypted
                  </p>
                  <p className="text-xs text-red-600 font-semibold">
                    ⚡ Price increases to $1,250 after timer expires
                  </p>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Bundle Offer Section - Updated to include 3-hour course */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-blue-100 text-blue-800 px-6 py-3 text-lg font-bold mb-6 shadow-sm hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300">
              <Package className="w-6 h-6 mr-2" />
              COMPLETE AI MASTERY BUNDLE
            </Badge>
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
              The Ultimate AI Learning Journey
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Get all three courses together - from introduction to advanced implementation - and save over 50% on your AI for executives education.
            </p>
          </div>

          <Card className="overflow-hidden shadow-2xl border-2 border-blue-500">
            <div className="grid lg:grid-cols-2">
              <div className="p-8 md:p-12 bg-white">
                <h3 className="text-3xl font-bold text-gray-900 mb-6">Complete Bundle Includes:</h3>
                <ul className="space-y-4 text-gray-700">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold">3 Hour AI Mastermind</h4>
                      <p className="text-sm text-gray-600">Fast-track AI for productivity introduction and career positioning</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold">Level 1: AI Skills Foundation</h4>
                      <p className="text-sm text-gray-600">15-Hour Comprehensive AI strategy course Training</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold">Level 2: AI Skills Accelerator</h4>
                      <p className="text-sm text-gray-600">30-Hour Advanced AI workflow automation System Building</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold">All Bonuses & Community Access</h4>
                      <p className="text-sm text-gray-600">Lifetime support and exclusive Generative AI resources.</p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="p-8 md:p-12 bg-gradient-to-br from-blue-600 to-purple-600 text-white flex flex-col items-center justify-center text-center">
                <h3 className="text-2xl font-bold mb-4">Total Individual Value: <span className="line-through opacity-80">$3,900</span></h3>
                <p className="text-6xl font-extrabold text-yellow-300 mb-2">$1,850</p>
                <Badge className="bg-yellow-400 text-gray-900 text-lg font-bold px-4 py-2 mb-8">
                  Save Over $2,000!
                </Badge>
                <StripePaymentLinkButton
                  href="https://buy.stripe.com/dR6dUa5P7gUYeasasF"
                  className="bg-white hover:bg-gray-200 text-blue-600 hover:text-blue-700 px-12 py-6 rounded-xl shadow-2xl font-bold text-xl transform hover:scale-105 transition-all duration-300">

                  Get Complete Bundle
                  <ArrowRight className="w-6 h-6 ml-3" />
                </StripePaymentLinkButton>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold mb-6">Success Stories</h2>
            <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
              {testimonials.map((testimonial, index) =>
                <Card key={index} className="bg-gray-50 border-gray-200">
                  <CardContent className="p-6">
                    <div className="flex mb-3">
                      {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
                    </div>
                    <p className="text-gray-600 mb-4 italic">"{testimonial.quote}"</p>
                    <p className="font-bold">{testimonial.author}</p>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced FAQ Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600">Everything you need to know about the Skills Foundation course program</p>
          </div>

          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {Object.keys(faqsData).map((category) =>
              <Button
                key={category}
                variant={activeFAQCategory === category ? 'default' : 'outline'}
                onClick={() => {
                  setActiveFAQCategory(category);
                  setOpenFAQ(0);
                }}
                className={`rounded-full transition-all duration-300 ${activeFAQCategory === category ? 'bg-blue-600 text-white hover:bg-blue-700 border-blue-600' : 'bg-white text-gray-800 border-gray-300 hover:bg-gray-100'}`}>

                {category}
              </Button>
            )}
          </div>

          <div className="space-y-4">
            {faqsData[activeFAQCategory].map((faq, index) =>
              <Card key={index} className="rounded-xl shadow-sm border-gray-200 overflow-hidden">
                <button
                  className="w-full text-left p-6 hover:bg-gray-50 transition-colors duration-200"
                  onClick={() => setOpenFAQ(openFAQ === index ? -1 : index)}>

                  <div className="flex justify-between items-center">
                    <h3 className="font-semibold text-lg text-gray-900 pr-4">{faq.q}</h3>
                    <div className="flex-shrink-0 bg-gray-100 rounded-full w-8 h-8 flex items-center justify-center">
                      {openFAQ === index ?
                        <ChevronUp className="w-5 h-5 text-blue-600" /> :
                        <ChevronDown className="w-5 h-5 text-gray-500" />
                      }
                    </div>
                  </div>
                </button>
                {openFAQ === index &&
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="px-6 pb-6">

                    <p className="text-gray-600 leading-relaxed border-l-2 border-blue-500 pl-4">{faq.a}</p>
                  </motion.div>
                }
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Free Download Section - Enhanced */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-600 to-indigo-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 sm:p-12 border border-white/20">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-2xl w-20 h-20 flex items-center justify-center mx-auto mb-8 shadow-lg">
              <Download className="w-10 h-10 text-gray-900" />
            </div>

            <h2 className="text-3xl sm:text-4xl font-bold mb-6">
              Download Your Free AI for Productivity Toolkit
            </h2>

            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto leading-relaxed">
              Get our exclusive "AI for Business" starter kit, including 25+ high-impact Generative AI prompts for marketing and operations, a checklist for identifying AI automation opportunities, and our guide to the top 5 free AI tools.
            </p>

            {!isSubmitted ?
              <form onSubmit={handleLeadSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto mb-8">
                <input
                  type="email"
                  placeholder="Enter your business email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="flex-1 px-4 py-3 rounded-lg text-gray-900 placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-yellow-400" />

                <Button
                  type="submit"
                  className="bg-yellow-400 hover:bg-yellow-300 text-gray-900 px-8 py-3 font-bold whitespace-nowrap rounded-lg">

                  <Download className="w-4 h-4 mr-2" />
                  Download Now
                </Button>
              </form> :

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center justify-center gap-3 text-green-300 mb-8 bg-green-600/20 p-6 rounded-xl border border-green-400/30">

                <CheckCircle2 className="w-6 h-6" />
                <span className="text-lg font-semibold">Success! Check your inbox for the AI workflow automation toolkit.</span>
              </motion.div>
            }

            <div className="flex flex-wrap justify-center items-center gap-6 text-sm">
              <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span>Instant Download</span>
              </div>
              <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full">
                <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                <span>No Spam Policy</span>
              </div>
              <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full">
                <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                <span>9,000+ Downloads</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA - Updated */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6">
            Your AI for Business Leaders Transformation Begins Now
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Stop falling behind. In one week, you can gain the AI automation skills that will define the next decade of your career.
          </p>
          <div className="text-center space-y-4">
            <p className="text-lg text-blue-200">
              <span className="line-through opacity-75">Regular Price: $1,250</span>
            </p>
            <Button onClick={scrollToForm} size="lg" className="bg-white text-blue-600 hover:bg-gray-100 px-10 py-4 rounded-xl shadow-lg group text-lg font-bold">
              Enroll in Level 1 - Only $900
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
            <p className="text-sm text-blue-200">
              💰 Save $350 with Early Bird Pricing - Limited Time!
            </p>
          </div>
        </div>
      </section>
    </div>);

}
