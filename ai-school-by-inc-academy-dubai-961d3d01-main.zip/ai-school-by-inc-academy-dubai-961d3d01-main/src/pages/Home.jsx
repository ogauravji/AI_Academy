import React, { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Brain, Globe } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import HeroSection from "@/components/landing/HeroSection";
import TargetAudience from "@/components/landing/TargetAudience";
import CourseModules from "@/components/landing/CourseModules";
import InstructorProfile from "@/components/landing/InstructorProfile";
import ClientLogos from "@/components/landing/ClientLogos";
import Testimonials from "@/components/landing/Testimonials";
import RealOutcomes from "@/components/landing/RealOutcomes";
import FAQ from "@/components/landing/FAQ";
import LeadMagnet from "@/components/landing/LeadMagnet";
import AIJobsBanner from "@/components/landing/AIJobsBanner";

export default function Home() {
  useEffect(() => {
    const setMetaTag = (attr, attrValue, content) => {
      let element = document.querySelector(`meta[${attr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const title = "AI Marketing Training, Courses & Consultancy | Inc. Academy";
    const description = "Lead the future of marketing with AI. Inc. Academy offers expert-led AI training, corporate workshops, and strategic consultancy to scale your business. Join 9,000+ professionals.";
    const imageUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/dbd194a74_TheAIRevolution.jpeg";

    document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:url', window.location.href);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <HeroSection />
      <ClientLogos />
      <TargetAudience />
      <CourseModules />
      <InstructorProfile />
      <RealOutcomes />
      <Testimonials />
      <AIJobsBanner />
      <FAQ />
      <LeadMagnet />
    </div>
  );
}