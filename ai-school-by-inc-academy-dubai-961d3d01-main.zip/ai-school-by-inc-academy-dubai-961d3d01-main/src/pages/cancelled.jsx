import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { XCircle, ArrowLeft, MessageSquare } from 'lucide-react';

export default function Cancelled() {
  useEffect(() => {
    document.title = "Payment Cancelled | Inc. Academy";
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-yellow-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl text-center shadow-2xl border-red-200">
        <CardHeader className="bg-red-50 rounded-t-lg">
          <div className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <XCircle className="w-12 h-12 text-white" />
          </div>
          <CardTitle className="text-3xl font-bold text-gray-900">Payment Cancelled</CardTitle>
        </CardHeader>
        <CardContent className="p-8">
          <p className="text-lg text-gray-700 mb-6">
            Your payment process was cancelled. You have not been charged.
          </p>
          <p className="text-gray-600 mb-8">
            If you need assistance or have questions, feel free to contact us.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ai-courses")}>
              <Button size="lg" variant="outline" className="w-full sm:w-auto">
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Courses
              </Button>
            </Link>
            <Button size="lg" className="w-full sm:w-auto bg-green-600 hover:bg-green-700" onClick={() => window.open('https://wa.me/971524371377', '_blank')}>
              <MessageSquare className="w-5 h-5 mr-2" />
              Contact Support
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}