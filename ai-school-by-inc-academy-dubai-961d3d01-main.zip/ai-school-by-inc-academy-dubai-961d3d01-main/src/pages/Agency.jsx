
import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Rocket,
  Target,
  Zap,
  BarChart3,
  Users,
  CheckCircle2,
  ArrowRight,
  Brain,
  TrendingUp,
  MessageSquare,
  PenTool,
  Award,
  Megaphone,
  ShoppingBag,
  Package,
  Building2,
  Home,
  Banknote,
  Bot,
  Sparkles,
  Factory,
  HeartPulse,
  BrainCircuit,
  Infinity,
  Clock,
  DollarSign // Added DollarSign import
} from "lucide-react";
import { motion } from "framer-motion";
import InquiryFormModal from "@/components/common/InquiryFormModal";

const services = [
  {
    icon: Target,
    title: "AI-Powered Funnel Strategy",
    description: "Complete funnel optimization using AI insights and automated testing frameworks that adapt in real-time.",
    features: ["Conversion optimization", "A/B testing automation", "Personalization at scale", "Predictive performance tracking"]
  },
  {
    icon: PenTool,
    title: "Content Automation Agents",
    description: "Deploy autonomous AI agents that create, optimize, and distribute high-quality content across all your marketing channels.",
    features: ["Blog & article generation", "Social media content creation", "Automated email sequences", "Video scriptwriting"]
  },
  {
    icon: BarChart3,
    title: "Performance Marketing + AI Analytics",
    description: "Data-driven campaigns powered by predictive analytics, automated budget allocation, and creative optimization.",
    features: ["Predictive audience targeting", "Automated budget optimization", "AI-driven creative testing", "Performance forecasting"]
  },
  {
    icon: Brain,
    title: "Custom GPT & AI Agent Development",
    description: "We build tailored AI assistants for ads, emails, outreach, and complex customer communication workflows.",
    features: ["Ad copy generation agents", "Automated email responders", "Lead qualification bots", "Customer support assistants"]
  },
  {
    icon: Users,
    title: "AI-Personalized Retargeting",
    description: "Advanced retargeting campaigns with AI-driven personalization and dynamic creative that adapts to user behavior.",
    features: ["Dynamic ad creative generation", "Behavioral targeting funnels", "Cross-platform campaigns", "Automated conversion optimization"]
  },
  {
    icon: TrendingUp,
    title: "Growth Acceleration Programs",
    description: "Comprehensive growth programs combining our proprietary AI tools with proven marketing strategies for rapid scaling.",
    features: ["AI-driven growth strategy", "Automated channel optimization", "Scalable AI frameworks", "Real-time performance monitoring"]
  }
];

const differentiators = [
  {
    icon: Users,
    title: "Built by Marketers, not Engineers",
    description: "Our team understands marketing challenges from experience, not theory"
  },
  {
    icon: Award,
    title: "Deep Expertise in Growth + AI",
    description: "15+ years of growth hacking combined with cutting-edge AI implementation"
  },
  {
    icon: Zap,
    title: "Speed to Deployment",
    description: "Days, not months. We get your AI systems up and running fast"
  }
];

const agentData = {
  "Marketing": {
    icon: Megaphone,
    color: "from-purple-500 to-pink-500",
    bgColor: "bg-gradient-to-r from-purple-50 to-pink-50",
    agents: [
      {
        title: "Campaign Optimizer Agent",
        description: "Adjusts budgets, creatives, and audience targeting in real-time across platforms.",
        icon: Target
      },
      {
        title: "Customer Persona Generator",
        description: "Builds dynamic personas using CRM, web analytics, and sales data.",
        icon: Users
      },
      {
        title: "AI Creative Brief Assistant",
        description: "Converts product or promo goals into AI-ready creative briefs for content or ad generation.",
        icon: Sparkles
      },
      {
        title: "Performance Insights Bot",
        description: "Delivers daily summaries of campaign KPIs and trends with executive-level commentary.",
        icon: TrendingUp
      }
    ]
  },
  "E-Commerce & D2C": {
    icon: ShoppingBag,
    color: "from-green-500 to-emerald-500",
    bgColor: "bg-gradient-to-r from-green-50 to-emerald-50",
    agents: [
      {
        title: "Product Copywriter Agent",
        description: "Writes SEO-friendly product titles, benefits, and specs in brand tone.",
        icon: Bot
      },
      {
        title: "AI Visual Merchandiser",
        description: "Optimizes product placement on web/app based on behavioral data.",
        icon: TrendingUp
      },
      {
        title: "Cart Abandonment Rescuer Bot",
        description: "Sends smart, personalized nudges to recover lost sales via WhatsApp/email.",
        icon: Zap
      },
      {
        title: "Review Summarizer Bot",
        description: "Analyzes customer feedback and auto-generates sentiment-based product insights.",
        icon: Users
      }
    ]
  },
  "Healthcare": {
    icon: HeartPulse,
    color: "from-red-500 to-orange-500",
    bgColor: "bg-gradient-to-r from-red-50 to-orange-50",
    agents: [
      {
        title: "Patient Triage Bot",
        description: "Provides initial assessment and directs patients to the appropriate level of care, reducing wait times.",
        icon: Users
      },
      {
        title: "Diagnostic Imaging Analyst",
        description: "Assists radiologists by highlighting potential anomalies in X-rays, MRIs, and CT scans.",
        icon: Brain
      },
      {
        title: "Personalized Treatment Planner",
        description: "Generates customized treatment plan suggestions based on patient data and medical guidelines.",
        icon: PenTool
      },
      {
        title: "Clinical Trial Recruitment Agent",
        description: "Scans patient records to identify and contact eligible candidates for clinical trials automatically.",
        icon: Zap
      }
    ]
  },
  "B2B & SaaS": {
    icon: Building2,
    color: "from-blue-500 to-indigo-500",
    bgColor: "bg-gradient-to-r from-blue-50 to-indigo-50",
    agents: [
      {
        title: "Outbound Sales Agent",
        description: "Crafts hyper-personalized cold emails using ICP data and previous interactions.",
        icon: Target
      },
      {
        title: "Proposal Generator Agent",
        description: "Auto-creates proposals, decks, and pricing sheets customized to client needs.",
        icon: Bot
      },
      {
        title: "Client Health Monitor",
        description: "Analyzes usage data and support tickets to identify churn risks.",
        icon: TrendingUp
      },
      {
        title: "B2B Growth Dashboard Bot",
        description: "Combines CRM, ad, and revenue data into a single, daily snapshot for leadership.",
        icon: Sparkles
      }
    ]
  },
  "Real Estate": {
    icon: Home,
    color: "from-cyan-500 to-teal-500",
    bgColor: "bg-gradient-to-r from-cyan-50 to-teal-50",
    agents: [
      {
        title: "Listing Intelligence Bot",
        description: "Generates SEO listings, ads, and social content for properties.",
        icon: Bot
      },
      {
        title: "Lead Nurture Bot",
        description: "Engages leads with local property insights, investment guides, and site visit bookings.",
        icon: Users
      },
      {
        title: "ROI Projection Agent",
        description: "Calculates long-term yield, IRR, and price appreciation based on location and property type.",
        icon: TrendingUp
      },
      {
        title: "Developer Dashboard Agent",
        description: "Summarizes sales funnel, inquiries, and top-performing agents weekly.",
        icon: Sparkles
      }
    ]
  },
  "Finance & Banking": {
    icon: Banknote,
    color: "from-emerald-500 to-green-600",
    bgColor: "bg-gradient-to-r from-emerald-50 to-green-50",
    agents: [
      {
        title: "Credit Risk Analyzer",
        description: "Flags anomalies and potential risk factors in loan applications using historical repayment models.",
        icon: Target
      },
      {
        title: "Portfolio Summary Agent",
        description: "Prepares visual performance summaries for clients and advisors.",
        icon: TrendingUp
      },
      {
        title: "AML Compliance Assistant",
        description: "Detects suspicious transaction patterns and compliance breaches.",
        icon: Zap
      },
      {
        title: "Chatbot Banker",
        description: "Answers customer FAQs, tracks spending patterns, and nudges users to save/invest.",
        icon: Bot
      }
    ]
  }
};

function AgentShowcase() {
  const [activeTab, setActiveTab] = useState("Marketing");

  return (
    <div className="w-full">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 lg:grid-cols-6 h-auto mb-8 bg-gray-100 rounded-2xl p-2">
          {Object.keys(agentData).map((industry) => {
            const IndustryIcon = agentData[industry].icon;
            return (
              <TabsTrigger
                key={industry}
                value={industry}
                className="text-xs md:text-sm font-medium px-2 py-3 rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-sm transition-all duration-300"
              >
                <div className="flex flex-col items-center gap-2">
                  <IndustryIcon className="w-4 h-4 md:w-5 md:h-5" />
                  <span className="hidden sm:block">{industry}</span>
                  <span className="sm:hidden">{industry.split(' ')[0]}</span>
                </div>
              </TabsTrigger>
            );
          })}
        </TabsList>

        {Object.entries(agentData).map(([industry, data]) => {
          const DataIcon = data.icon;
          return (
            <TabsContent key={industry} value={industry} className="mt-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className={`rounded-3xl p-6 md:p-8 mb-8 ${data.bgColor}`}
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className={`w-12 h-12 md:w-16 md:h-16 rounded-2xl bg-gradient-to-r ${data.color} flex items-center justify-center shadow-lg`}>
                    <DataIcon className="w-6 h-6 md:w-8 md:h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl md:text-3xl font-bold text-gray-900">{industry}</h3>
                    <p className="text-gray-600">AI-powered solutions for modern {industry.toLowerCase()}</p>
                  </div>
                </div>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {data.agents.map((agent, index) => {
                  const AgentIcon = agent.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                    >
                      <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 group h-full bg-white rounded-2xl overflow-hidden">
                        <CardHeader className="pb-4">
                          <div className="flex items-start gap-4">
                            <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-500 to-green-500 flex items-center justify-center shadow-md group-hover:scale-110 transition-transform duration-300">
                              <AgentIcon className="w-6 h-6 text-white" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <CardTitle className="text-lg font-bold text-gray-900 leading-tight group-hover:text-purple-600 transition-colors">
                                {agent.title}
                              </CardTitle>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                            {agent.description}
                          </p>
                          <div className="mt-4 pt-4 border-t border-gray-100">
                            <Badge variant="secondary" className="text-xs font-medium">
                              AI Powered
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>
            </TabsContent>
          );
        })}
      </Tabs>
    </div>
  );
}

export default function Agency() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState({ title: "Start Your Project", subtitle: "Let's discuss how our AI agency services can accelerate your growth." });
  const aiAgentsRef = useRef(null);

  useEffect(() => {
    const setMetaTag = (attr, attrValue, content) => {
      let element = document.querySelector(`meta[${attr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const title = "AI Marketing Agency Dubai UAE | ChatGPT Automation & Agent Development - Inc. Academy";
    const description = "Top AI marketing agency in Dubai UAE. We build ChatGPT agents, marketing automation, funnel optimization & campaign management. Done-for-you AI solutions to scale your business in UAE.";
    const imageUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f369242ee_AICorporate.png";

    document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:url', window.location.href);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);
  }, []);

  const openModal = () => setIsModalOpen(true);
  const scrollToShowcase = () => {
    aiAgentsRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <InquiryFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={modalContent.title}
        subtitle={modalContent.subtitle}
      />

      <div className="min-h-screen bg-white">
        {/* Hero Section */}
        <section className="relative py-20 md:py-32 px-4 sm:px-6 lg:px-8 overflow-hidden bg-gradient-to-br from-gray-900 via-blue-900 to-black">
          {/* Background Elements */}
          <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
          <div className="absolute top-10 right-10 w-80 h-80 bg-gradient-to-r from-blue-500/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-10 left-10 w-96 h-96 bg-gradient-to-r from-green-500/20 to-transparent rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>

          <div className="text-white mx-auto px-4 relative max-w-7xl sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-6 md:mb-8 text-center"
            >
              <Badge className="px-6 py-3 text-base font-semibold bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-full shadow-lg">
                <Zap className="w-5 h-5 mr-3" />
                Done-For-You AI Solutions
              </Badge>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-8 text-center leading-tight"
            >
              <span className="text-white block mb-4">Your AI Marketing</span>
              <span className="bg-gradient-to-r from-blue-400 via-green-400 to-cyan-400 bg-clip-text text-transparent block">
                Implementation Partner
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-xl text-gray-300 mb-12 max-w-4xl mx-auto text-center leading-relaxed font-light"
            >
              From custom AI agents to automated marketing funnels, we handle the entire implementation
              so you can focus on scaling your business with proven AI strategies.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-6 justify-center mb-16"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white px-10 py-4 text-lg font-semibold rounded-2xl shadow-lg group transform hover:scale-105 transition-transform"
                onClick={openModal}
              >
                Get Your AI Agent Built
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>

              <Button
                size="lg"
                variant="outline"
                className="bg-white/10 backdrop-blur-md text-white border-2 border-white/30 hover:bg-white/20 px-10 py-4 text-lg font-semibold rounded-2xl group"
                onClick={scrollToShowcase}
              >
                View AI Agents
              </Button>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center"
            >
              <div className="group">
                <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-400 to-green-400 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300">50+</div>
                <div className="mt-2 text-gray-300">AI Agents Built</div>
              </div>
              <div className="group">
                <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-green-400 to-cyan-400 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300">300+</div>
                <div className="mt-2 text-gray-300">Brands Served</div>
              </div>
              <div className="group">
                <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300">85%</div>
                <div className="mt-2 text-gray-300">Cost Reduction</div>
              </div>
              <div className="group">
                <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent group-hover:scale-110 transition-transform duration-300">24/7</div>
                <div className="mt-2 text-gray-300">AI Operations</div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Section Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent"></div>

        {/* Services Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <Badge className="px-6 py-3 text-base font-semibold bg-blue-50 text-blue-700 border-0 mb-8">
                <Target className="w-5 h-5 mr-2" />
                Our Services
              </Badge>
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Complete AI Marketing
                <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent"> Solutions</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                From strategy to execution, we provide end-to-end AI-powered marketing services
                that scale your business efficiently
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service, index) => (
                <Card key={index} className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 group bg-white p-2">
                  <div className="bg-gray-50 rounded-2xl p-6 h-full">
                    <CardHeader className="pb-4">
                      <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                        <service.icon className="w-8 h-8 text-white" />
                      </div>
                      <CardTitle className="text-xl font-bold text-gray-900 mb-4 group-hover:text-green-600 transition-colors">
                        {service.title}
                      </CardTitle>
                      <p className="text-gray-600 leading-relaxed mb-6">
                        {service.description}
                      </p>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="space-y-3">
                        {service.features.map((feature, featureIndex) => (
                          <div key={featureIndex} className="flex items-center gap-3">
                            <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                            <span className="text-gray-700 text-sm">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* AI Disruption Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <Badge className="px-6 py-3 text-base font-semibold bg-red-50 text-red-600 border-0 mb-8">
                <Zap className="w-5 h-5 mr-2" />
                Industry Revolution
              </Badge>
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                AI is Disrupting
                <span className="bg-gradient-to-r from-red-600 to-orange-500 bg-clip-text text-transparent block mt-2">
                  Every Industry
                </span>
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                From healthcare to finance, retail to manufacturing—no sector is immune to AI transformation.
                The companies that adapt quickly will dominate their markets.
              </p>
            </div>

            {/* Main Content Grid */}
            <div className="grid lg:grid-cols-2 gap-16 items-center mb-16">
              {/* Left Column - Hero Image */}
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8 }}
                className="relative order-2 lg:order-1"
              >
                <div className="relative z-10">
                  <div className="aspect-[4/3] bg-gradient-to-br from-blue-100 to-green-100 rounded-3xl shadow-2xl overflow-hidden ring-4 ring-white/50">
                    <img
                      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f369242ee_AICorporate.png"
                      alt="AI robots and business analysts working with data visualization in modern Dubai UAE office, representing AI transformation"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                {/* Background decorative elements */}
                <div className="absolute top-8 -right-8 w-24 h-24 md:w-32 md:h-32 bg-blue-200/60 rounded-full blur-3xl animate-pulse"></div>
                <div className="absolute -bottom-8 -left-8 w-32 h-32 md:w-40 md:h-40 bg-green-200/60 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
              </motion.div>

              {/* Right Column - Content */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8 }}
                className="order-1 lg:order-2"
              >
                <h3 className="text-3xl font-bold text-gray-900 mb-6">Companies Using AI Are Already Winning</h3>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                      <TrendingUp className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">40% Faster Decision Making</h4>
                      <p className="text-gray-600">AI-powered analytics enable real-time insights and instant strategic adjustments</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0">
                      <DollarSign className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">60% Cost Reduction</h4>
                      <p className="text-gray-600">Automation eliminates manual processes and optimizes resource allocation</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-red-500 to-red-600 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">3x Better Customer Experience</h4>
                      <p className="text-gray-600">Personalized interactions and 24/7 AI support create unmatched customer satisfaction</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Industry Cards Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  icon: ShoppingBag,
                  title: "E-commerce",
                  desc: "Hyper-personalized shopping experiences and predictive inventory.",
                  image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
                  color: "from-blue-500 to-blue-600"
                },
                {
                  icon: HeartPulse,
                  title: "Healthcare",
                  desc: "Accelerated drug discovery and predictive patient diagnostics.",
                  image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
                  color: "from-green-500 to-green-600"
                },
                {
                  icon: Banknote,
                  title: "Finance",
                  desc: "Algorithmic trading, fraud detection, and automated risk assessment.",
                  image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
                  color: "from-gray-700 to-gray-900"
                },
                {
                  icon: Factory,
                  title: "Manufacturing",
                  desc: "Predictive maintenance, quality control, and supply chain optimization.",
                  image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
                  color: "from-blue-600 to-green-600"
                }
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.3 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 group text-center h-full rounded-2xl overflow-hidden">
                    <div className="relative">
                      <div className="aspect-[4/3] overflow-hidden">
                        <img
                          src={item.image}
                          alt={`${item.title} industry AI transformation in Dubai UAE - modern technology and automation solutions`}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                      </div>
                      <div className={`absolute top-4 left-4 w-12 h-12 bg-gradient-to-r ${item.color} rounded-xl flex items-center justify-center shadow-lg`}>
                        <item.icon className="w-6 h-6 text-white" />
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">{item.title}</h3>
                      <p className="text-gray-600 leading-relaxed text-sm">{item.desc}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Why Us Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <Badge className="px-6 py-3 text-base font-semibold bg-blue-50 text-blue-700 border-0 mb-8 rounded-full shadow-sm">
                <Users className="w-5 h-5 mr-2" />
                Why Choose Us
              </Badge>
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Built for
                <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent"> Results</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                We're not just another agency. We're marketing experts who leverage AI to
                deliver exceptional results for our clients.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {differentiators.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.3 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                >
                  <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 group bg-white/80 backdrop-blur-sm h-full rounded-3xl overflow-hidden">
                    <div className="bg-gray-50 rounded-3xl p-8 h-full">
                      <CardContent className="p-0 text-center h-full flex flex-col">
                        <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                          <item.icon className="w-8 h-8 text-white" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors">
                          {item.title}
                        </h3>
                        <p className="text-gray-600 leading-relaxed flex-grow">{item.description}</p>

                        <div className="mt-6 pt-4 border-t border-gray-100">
                          <div className="w-12 h-1 bg-gradient-to-r from-blue-400 to-green-400 rounded-full mx-auto opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                        </div>
                      </CardContent>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="mt-16 text-center"
            >
              <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 md:p-12 shadow-xl border border-white/40 max-w-4xl mx-auto">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <blockquote className="text-lg md:text-xl text-gray-700 italic mb-6 leading-relaxed">
                  "The combination of marketing expertise and AI implementation is what sets this team apart. They don't just understand the technology—they understand how to make it work for real business growth."
                </blockquote>
                <div className="text-sm text-gray-500 font-medium">
                  Based on client feedback from 300+ brand transformations
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Custom AI Agents Section - Enhanced */}
        <section ref={aiAgentsRef} className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/30">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <Badge className="px-6 py-3 text-base font-semibold bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 border border-purple-200 mb-8 rounded-full shadow-sm">
                <Brain className="w-5 h-5 mr-2" />
                AI-Powered Industry Solutions
              </Badge>
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Custom AI Agents for
                <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent block md:inline md:ml-3">
                  Every Industry
                </span>
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                Discover powerful, industry-specific AI agents designed to automate workflows,
                boost productivity, and transform business operations across sectors.
              </p>
            </div>

            {/* Hero Image Section */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8 }}
              className="relative mb-16"
            >
              <div className="aspect-[16/9] bg-gradient-to-br from-blue-100 to-purple-100 rounded-3xl shadow-2xl overflow-hidden ring-4 ring-white/50 relative">
                <img
                  src="https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80"
                  alt="Diverse AI agents working in various industries, symbolizing cross-sector automation and innovation"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>

                {/* Floating industry icons */}
                <div className="absolute top-8 left-8 w-16 h-16 bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center shadow-xl animate-float">
                  <Megaphone className="w-8 h-8 text-white" />
                </div>
                <div className="absolute top-8 right-8 w-16 h-16 bg-gradient-to-r from-green-600 to-green-700 rounded-2xl flex items-center justify-center shadow-xl animate-float" style={{ animationDelay: '1s' }}>
                  <ShoppingBag className="w-8 h-8 text-white" />
                </div>
                <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 w-16 h-16 bg-gradient-to-r from-purple-600 to-purple-700 rounded-2xl flex items-center justify-center shadow-xl animate-float" style={{ animationDelay: '2s' }}>
                  <Building2 className="w-8 h-8 text-white" />
                </div>

                {/* Central content overlay */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white max-w-2xl px-8">
                    <h3 className="text-3xl md:text-4xl font-bold mb-4">AI Transformation Across All Sectors</h3>
                    <p className="text-lg text-white/90">From healthcare to finance, our AI agents are revolutionizing how businesses operate and compete.</p>
                  </div>
                </div>
              </div>

              {/* Decorative background elements */}
              <div className="absolute top-12 -left-12 w-32 h-32 bg-blue-200/40 rounded-full blur-3xl"></div>
              <div className="absolute -bottom-12 -right-12 w-40 h-40 bg-purple-200/40 rounded-full blur-3xl"></div>
            </motion.div>

            <div className="relative">
              {/* Background decorative elements */}
              <div className="absolute -top-8 -left-8 w-64 h-64 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
              <div className="absolute -bottom-8 -right-8 w-80 h-80 bg-gradient-to-br from-green-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '3s' }}></div>

              {/* Main container with enhanced design */}
              <div className="relative bg-white/80 backdrop-blur-lg rounded-3xl p-8 md:p-12 shadow-2xl border border-white/60 ring-1 ring-purple-200/20 overflow-hidden">
                {/* Top gradient accent */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-green-500"></div>

                {/* Subtle pattern overlay */}
                <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none"></div>

                {/* Content wrapper */}
                <div className="relative z-10">
                  {/* Section header inside container */}
                  <div className="text-center mb-12">
                    <div className="inline-flex items-center gap-3 bg-gradient-to-r from-purple-50 to-blue-50 px-6 py-3 rounded-2xl border border-purple-200/50 mb-6">
                      <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                        <Brain className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-purple-700 font-semibold">Explore Industry Solutions</span>
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
                      Choose Your <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">Industry Focus</span>
                    </h3>
                    <p className="text-gray-600 max-w-2xl mx-auto">
                      Select an industry below to discover specialized AI agents tailored for your business sector
                    </p>
                  </div>

                  <AgentShowcase />
                </div>

                {/* Bottom decorative elements */}
                <div className="absolute bottom-4 left-4 w-20 h-20 bg-gradient-to-br from-blue-100/50 to-transparent rounded-full blur-xl"></div>
                <div className="absolute bottom-4 right-4 w-24 h-24 bg-gradient-to-br from-green-100/50 to-transparent rounded-full blur-xl"></div>
              </div>
            </div>

            {/* Call-to-action Box */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="mt-16"
            >
              <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-3xl p-8 md:p-12 text-white text-center shadow-2xl relative overflow-hidden">
                {/* Background decorative elements */}
                <div className="absolute top-8 right-8 w-24 h-24 bg-white/10 rounded-full blur-2xl"></div>
                <div className="absolute bottom-8 left-8 w-32 h-32 bg-white/10 rounded-full blur-3xl"></div>

                <div className="relative z-10">
                  <h3 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-4 md:mb-6">
                    Ready to Build Your Custom AI Agent?
                  </h3>
                  <p className="text-lg md:text-xl text-blue-100 mb-6 md:mb-8 max-w-3xl mx-auto">
                    Let our experts create industry-specific AI solutions tailored to your business needs and workflows.
                  </p>
                  <Button
                    size="lg"
                    className="bg-white text-blue-600 hover:bg-gray-100 hover:text-blue-700 px-8 md:px-12 py-3 md:py-4 text-base md:text-lg font-bold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 group transform hover:scale-105"
                    onClick={openModal}
                  >
                    Start Your AI Transformation
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Enhanced Productivity Section */}
        <section className="bg-gradient-to-br from-teal-50/40 via-blue-50/40 to-white py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8 }}
            >
              <Badge className="px-6 py-3 text-base font-semibold bg-teal-100 text-teal-700 border-0 mb-8 rounded-full shadow-sm">
                <TrendingUp className="w-5 h-5 mr-2" />
                Enhanced Productivity
              </Badge>
              <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
                Work Smarter, Not Harder
              </h2>
              <p className="text-xl text-gray-600 mb-8 font-light leading-relaxed">
                Our AI solutions automate the mundane, liberating your team to focus on what matters most: strategy, creativity, and growth. Experience a new level of operational efficiency.
              </p>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-teal-500 to-cyan-500 text-white rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800">Reclaim 10+ Hours Weekly</h4>
                    <p className="text-gray-600">Automate reporting, data analysis, and content creation to free up valuable time for every team member.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 text-white rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800">5x Creative Output</h4>
                    <p className="text-gray-600">Generate multiple ad creatives, copy variations, and campaign ideas in minutes, not days.</p>
                  </div>
                </div>
              </div>
            </motion.div>
            <motion.div
              className="relative hidden lg:block"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="absolute -inset-4 bg-gradient-to-r from-teal-400 to-blue-500 rounded-3xl blur-2xl opacity-30 animate-pulse"></div>
              <img src="https://images.unsplash.com/photo-1611095790444-1dfa35e37b52?q=80&w=2940&auto=format&fit=crop" alt="Team collaborating efficiently with AI tools in a modern office, highlighting enhanced productivity" className="relative rounded-2xl shadow-xl" />
            </motion.div>
          </div>
        </section>

        {/* Future of AI Section */}
        <section className="relative py-20 px-4 sm:px-6 lg:px-8 bg-gray-900 text-white overflow-hidden">
          {/* Background Effects */}
          <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl animate-float"></div>
          <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '3s' }}></div>

          <div className="relative max-w-7xl mx-auto text-center z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Badge className="px-6 py-3 text-base font-semibold bg-white/10 text-cyan-300 border border-white/20 rounded-full backdrop-blur-sm mb-8">
                <BrainCircuit className="w-5 h-5 mr-3" />
                The Next Frontier of AI
              </Badge>
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
                The Age of
                <span className="bg-gradient-to-r from-blue-400 to-green-400 bg-clip-text text-transparent block md:inline md:ml-4">
                  Autonomous Agents
                </span>
              </h2>
              <p className="text-xl text-gray-300 max-w-4xl mx-auto font-light leading-relaxed mb-12">
                The next wave of AI isn't just about assisting humans—it's about autonomous systems that manage entire workflows. From marketing campaigns to customer service, AI agents will strategize, execute, and optimize with minimal oversight. We build these future-ready systems for you today.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                { icon: Brain, title: "Predictive Strategy", desc: "AI that anticipates market shifts and formulates proactive strategies." },
                { icon: Zap, title: "Self-Optimizing Systems", desc: "Campaigns that improve themselves based on real-time performance data." },
                { icon: Infinity, title: "End-to-End Automation", desc: "From first touch to final sale, entire customer journeys managed by AI." }
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.4 + index * 0.2 }}
                  className="bg-white/5 p-8 rounded-2xl border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all duration-300 group"
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-green-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <item.icon className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="text-xl font-semibold mb-2 text-white">{item.title}</h4>
                  <p className="text-gray-400">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-900 text-white relative overflow-hidden">
          {/* Background Effects - matching hero */}
          <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
          <div className="absolute top-0 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-green-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '3s' }}></div>

          <div className="relative max-w-4xl mx-auto text-center z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8 }}
              className="mb-6"
            >
              <Badge className="px-6 py-3 text-base font-semibold bg-gray-800/50 text-blue-400 border border-blue-400/30 rounded-full">
                <Rocket className="w-5 h-5 mr-3" />
                Ready to Scale
              </Badge>
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight tracking-tight"
            >
              <span className="text-white block">Ready to Scale Your Marketing</span>
              <span className="bg-gradient-to-r from-blue-400 to-green-400 bg-clip-text text-transparent block mt-2">
                with AI?
              </span>
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-xl text-gray-300 mb-12 leading-relaxed max-w-3xl mx-auto"
            >
              Let's discuss how we can transform your marketing operations with AI-powered solutions.
              Get started with a free consultation and see the possibilities.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-6 justify-center"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600 text-white px-10 py-4 text-lg font-bold rounded-xl shadow-lg shadow-blue-500/20 hover:shadow-xl transition-all duration-300 group"
                onClick={openModal}
              >
                Start Your Project
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
}
