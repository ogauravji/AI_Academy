import React from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Award, Users, Globe, TrendingUp, Target, CheckCircle2, 
  Brain, Rocket, Building, Star, ArrowRight, BrainCircuit
} from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const achievements = [
  { number: "9,000+", label: "Professionals Trained", icon: Users, color: "from-blue-500 to-blue-600" },
  { number: "300+", label: "Brands Consulted", icon: Building, color: "from-green-500 to-green-600" },
  { number: "15+", label: "Years Experience", icon: Award, color: "from-purple-500 to-purple-600" },
  { number: "25+", label: "Countries Reached", icon: Globe, color: "from-orange-500 to-orange-600" }
];

const clientLogos = [
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f2b001de0_5.png", alt: "Google" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a110c098b_18.png", alt: "TikTok" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/ebba4f908_24.png", alt: "Dubai Tourism" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d1e13dbdc_3.png", alt: "Emirates" }
];

const milestones = [
  {
    year: "2009",
    title: "Digital Marketing Pioneer",
    description: "Founded Inc. Academy as one of the first digital marketing training institutes in the MENA region."
  },
  {
    year: "2015", 
    title: "Google Partnership",
    description: "Became Google Regional Trainer, delivering official Google Ads and Analytics training across the region."
  },
  {
    year: "2020",
    title: "Strategic Consulting",
    description: "Expanded into strategic consultancy, working with Dubai Tourism for Expo 2020 and major regional brands."
  },
  {
    year: "2023",
    title: "AI Transformation",
    description: "Pioneered AI training in the region, becoming the leading provider of Generative AI and AI automation courses."
  },
  {
    year: "2024",
    title: "Global Expansion",
    description: "Launched AI strategy consultancy and implementation services, helping enterprises worldwide adopt AI."
  }
];

export default function About() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-900 via-blue-900 to-indigo-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Badge className="px-6 py-3 text-base font-semibold bg-white/20 text-white border border-white/30 mb-6">
                <Brain className="w-5 h-5 mr-2" />
                About Inc. Academy
              </Badge>
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6">
                Pioneering AI Education for
                <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent block mt-2">
                  15+ Years
                </span>
              </h1>
              <p className="text-xl text-blue-100 leading-relaxed mb-8">
                From digital marketing pioneers to AI transformation leaders, we've been at the forefront 
                of business education, empowering professionals and enterprises to thrive in the digital age.
              </p>
              <Link to={createPageUrl("ai-courses")}>
                <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 font-semibold rounded-xl">
                  Explore Our AI Courses
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <img
                src="https://images.unsplash.com/photo-1551434678-e076c223a692?q=80&w=2832&auto=format&fit=crop"
                alt="AI-generated image of modern digital training environment"
                className="rounded-3xl shadow-2xl w-full"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            <Card className="border border-blue-200 shadow-xl">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
                <p className="text-gray-600 leading-relaxed">
                  To democratize AI education and empower professionals worldwide with the skills, 
                  strategies, and confidence needed to lead in the age of Generative AI. We believe 
                  AI literacy should be accessible to everyone, not just technical experts.
                </p>
              </CardContent>
            </Card>

            <Card className="border border-purple-200 shadow-xl">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6">
                  <Rocket className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Vision</h3>
                <p className="text-gray-600 leading-relaxed">
                  To be the world's most trusted partner for AI transformation, creating a future 
                  where every business leader, entrepreneur, and professional can harness the power 
                  of AI to drive innovation, growth, and positive impact.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Our Impact by the Numbers
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              15+ years of consistent growth and impact in AI education and digital transformation.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className={`w-20 h-20 bg-gradient-to-r ${achievement.color} rounded-2xl flex items-center justify-center mx-auto mb-6`}>
                  <achievement.icon className="w-10 h-10 text-white" />
                </div>
                <div className="text-4xl font-bold text-gray-900 mb-2">{achievement.number}</div>
                <p className="text-gray-600 font-medium">{achievement.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="px-6 py-3 text-base font-semibold bg-blue-100 text-blue-700 border border-blue-200 mb-6">
              <Award className="w-5 h-5 mr-2" />
              Our Journey
            </Badge>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              15 Years of Innovation
            </h2>
            <p className="text-xl text-gray-600">
              From digital marketing pioneers to AI transformation leaders - our evolution story.
            </p>
          </div>

          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-blue-200"></div>
            
            {milestones.map((milestone, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="relative flex items-start mb-12 last:mb-0"
              >
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg">
                  {milestone.year}
                </div>
                <div className="ml-8 flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{milestone.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{milestone.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Founder Section */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/5bb702e8b_Gaurav_SiFi.png"
                alt="Gaurav Oberoi - Founder of Inc. Academy"
                className="rounded-3xl shadow-2xl w-full"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <Badge className="px-4 py-2 text-sm font-semibold bg-blue-100 text-blue-700 border border-blue-200 mb-6">
                <BrainCircuit className="w-4 h-4 mr-2" />
                Meet Our Founder
              </Badge>
              <h3 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
                Gaurav Oberoi
              </h3>
              <p className="text-xl text-blue-600 font-semibold mb-6">
                AI Strategist & Digital Transformation Expert
              </p>
              
              <p className="text-gray-600 leading-relaxed mb-8">
                With over 15 years of experience in digital marketing and AI strategy, Gaurav has 
                been instrumental in transforming how businesses approach technology adoption. 
                As a former Google Regional Trainer and consultant to major brands like Dubai Tourism, 
                he brings unparalleled expertise in making complex AI concepts accessible and actionable.
              </p>

              <div className="space-y-4 mb-8">
                {[
                  "Former Google Regional Trainer & TikTok MENA Collaborator",
                  "Strategic Advisor for Dubai Tourism (Expo 2020)",
                  "Trained 9,000+ professionals across 25+ countries", 
                  "Active startup investor and AI strategy consultant"
                ].map((achievement, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-1" />
                    <span className="text-gray-700">{achievement}</span>
                  </div>
                ))}
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-200">
                <p className="text-gray-600 italic text-lg mb-4">
                  "AI is not about replacing human creativity and strategy—it's about amplifying it. 
                  My mission is to ensure every business leader has the knowledge and confidence 
                  to harness AI for meaningful growth."
                </p>
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <span className="text-sm font-semibold text-gray-600">4.9/5 Average Rating</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Client Logos */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-center text-lg font-semibold text-gray-900 mb-8">
            Trusted by Industry Leaders
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center">
            {clientLogos.map((client, index) => (
              <img
                key={index}
                src={client.src}
                alt={client.alt}
                className="max-h-12 w-auto opacity-60 hover:opacity-100 transition-opacity"
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-gray-900 to-blue-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            Ready to Join the AI Revolution?
          </h2>
          <p className="text-xl text-blue-100 mb-8 leading-relaxed">
            Whether you're an individual looking to upskill or an enterprise seeking AI transformation, 
            we have the expertise and programs to help you succeed.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("ai-courses")}>
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-4 font-semibold rounded-xl">
                Explore AI Courses
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link to={createPageUrl("contact")}>
              <Button size="lg" variant="outline" className="bg-white/10 backdrop-blur-sm text-white border-2 border-white/30 hover:bg-white hover:text-gray-900 px-8 py-4 font-semibold rounded-xl">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}