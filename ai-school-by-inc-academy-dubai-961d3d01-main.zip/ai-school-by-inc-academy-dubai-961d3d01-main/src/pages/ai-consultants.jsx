import React from 'react';
import Consultancy from './Consultancy';

export default function AIConsultants() {
    return <Consultancy />;
}