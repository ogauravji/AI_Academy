import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, ShieldCheck } from "lucide-react";

export default function Terms() {
    React.useEffect(() => {
        document.title = "Terms & Conditions | Inc. Academy";
    }, []);

    const termsSections = [
        {
            title: "Introduction",
            content: "Welcome to Inc. Academy. These terms and conditions outline the rules and regulations for the use of Inc. Academy's Website, located at inc.academy. By accessing this website we assume you accept these terms and conditions. Do not continue to use Inc. Academy if you do not agree to take all of the terms and conditions stated on this page."
        },
        {
            title: "Intellectual Property Rights",
            content: "Other than the content you own, under these Terms, Inc. Academy and/or its licensors own all the intellectual property rights and materials contained in this Website. You are granted limited license only for purposes of viewing the material contained on this Website."
        },
        {
            title: "Restrictions",
            content: "You are specifically restricted from all of the following: publishing any Website material in any other media; selling, sublicensing and/or otherwise commercializing any Website material; publicly performing and/or showing any Website material; using this Website in any way that is or may be damaging to this Website; using this Website in any way that impacts user access to this Website; using this Website contrary to applicable laws and regulations, or in any way may cause harm to the Website, or to any person or business entity."
        },
        {
            title: "Your Content",
            content: "In these Website Standard Terms and Conditions, “Your Content” shall mean any audio, video text, images or other material you choose to display on this Website. By displaying Your Content, you grant Inc. Academy a non-exclusive, worldwide irrevocable, sub-licensable license to use, reproduce, adapt, publish, translate and distribute it in any and all media."
        },
        {
            title: "No warranties",
            content: "This Website is provided “as is,” with all faults, and Inc. Academy express no representations or warranties, of any kind related to this Website or the materials contained on this Website. Also, nothing contained on this Website shall be interpreted as advising you."
        },
        {
            title: "Limitation of liability",
            content: "In no event shall Inc. Academy, nor any of its officers, directors and employees, shall be held liable for anything arising out of or in any way connected with your use of this Website whether such liability is under contract. Inc. Academy, including its officers, directors and employees shall not be held liable for any indirect, consequential or special liability arising out of or in any way related to your use of this Website."
        },
        {
            title: "Governing Law & Jurisdiction",
            content: "These Terms will be governed by and interpreted in accordance with the laws of the United Arab Emirates, and you submit to the non-exclusive jurisdiction of the state and federal courts located in UAE for the resolution of any disputes."
        }
    ];

    return (
        <div className="min-h-screen bg-gray-50 py-20 px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
                <div className="text-center mb-16">
                    <Badge className="px-6 py-3 text-base font-semibold bg-blue-100 text-blue-700 border-blue-200 mb-8">
                        <ShieldCheck className="w-5 h-5 mr-2" />
                        Legal Framework
                    </Badge>
                    <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
                        Terms & Conditions
                    </h1>
                    <p className="text-xl text-gray-600">
                        Last updated: August 2024
                    </p>
                </div>

                <div className="space-y-8">
                    {termsSections.map((section, index) => (
                        <Card key={index} className="border-0 shadow-lg">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3 text-2xl text-gray-800">
                                    <FileText className="w-6 h-6 text-blue-600" />
                                    {section.title}
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-gray-700 leading-relaxed">
                                    {section.content}
                                </p>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>
        </div>
    );
}