import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import PaymentButton from '@/components/common/PaymentButton';
import {
  Calendar, Clock, Monitor, Target, CheckCircle2, TrendingUp, Briefcase, Rocket, Users, Award, Star, ArrowRight,
  BrainCircuit, AlertTriangle, DollarSign, Shield, BookOpen, Gift, Sparkles, Lightbulb, ChevronUp, ChevronDown, MessageCircle, Bot, Infinity
} from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import LearningOutcomes from '@/components/landing/LearningOutcomes';
import DetailedTestimonials from '@/components/landing/DetailedTestimonials';
import ProfessionalFAQ from '@/components/landing/ProfessionalFAQ';

const clientLogos = [
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f2b001de0_5.png", alt: "Google" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a110c098b_18.png", alt: "TikTok" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/ebba4f908_24.png", alt: "Dubai Tourism" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d1e13dbdc_3.png", alt: "Emirates" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/1f7695b87_13.png", alt: "Alshaya" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/c2a949770_22.png", alt: "Unilever" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d825d99f2_6.png", alt: "Etihad" },
  { src: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/da941e9d4_7.png", alt: "Harvard Business School" }];

export default function AIMastermind() {

  useEffect(() => {
    const setMetaTag = (attr, attrValue, content) => {
      let element = document.querySelector(`meta[${attr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const title = "3 Hour AI Mastermind: AI Skills to 10x Your Career | Inc. Academy";
    const description = "Join our intensive 3-hour AI Mastermind. Learn ChatGPT, AI for productivity, and AI workflow automation to secure your career in the AI age. Limited seats available.";
    const imageUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a16282cad_WhatsAppImage2025-08-13at33235PM.jpg";

    document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:url', window.location.href);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);
  }, []);


  const targetAudience = [
    { icon: TrendingUp, title: "Marketing & Sales Professionals" },
    { icon: Users, title: "HR & Finance Professionals" },
    { icon: Briefcase, title: "Consultants & Freelancers" },
    { icon: Rocket, title: "Entrepreneurs & Founders" }
  ];

  return (
    <div className="min-h-screen bg-slate-50 font-inter">
      {/* Hero Section */}
      <section className="relative bg-slate-900 text-white overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-[#1E40AF] to-slate-900 opacity-95"></div>
        <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }} className="text-center lg:text-left">
              <Badge className="bg-blue-600 text-white px-4 py-2 text-sm font-bold rounded-full mb-4 inline-block">
                <Sparkles className="w-4 h-4 mr-2" />
                PROFESSIONAL TRAINING
              </Badge>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black my-4 text-white leading-tight">AI Skills to 10x Your Career in 2025</h1>
              <p className="text-xl sm:text-2xl text-slate-200 mb-6 font-medium">3-Hour AI Mastermind: Tuesday, September 17th</p>

              <div className="bg-white/10 rounded-xl p-6 mb-8 border border-white/20">
                <div className="flex items-center justify-center lg:justify-start gap-4 mb-2">
                  <span className="text-2xl sm:text-3xl text-slate-400 line-through">$250</span>
                  <span className="text-4xl sm:text-5xl font-black text-white">$99</span>
                  <Badge className="bg-green-500 text-white px-3 py-1 font-bold">SAVE 60%</Badge>
                </div>
                <p className="text-sm text-slate-300 text-center lg:text-left">One-time investment for lifetime AI skills.</p>
              </div>

              <PaymentButton courseType="mastermind-session" size="lg" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-xl font-bold rounded-xl shadow-lg transform hover:scale-105 transition-transform">
                Reserve Your Seat - $99
              </PaymentButton>
            </motion.div>
            <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8, delay: 0.2 }} className="relative">
              <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a16282cad_WhatsAppImage2025-08-13at33235PM.jpg" alt="AI powered business intelligence and strategy meeting" className="rounded-2xl shadow-2xl w-full" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Logos Section */}
      <section className="py-8 sm:py-12 bg-slate-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-base sm:text-lg font-semibold text-slate-600 mb-6">Trusted by professionals from leading organizations who have attended our AI for business courses.</p>
          <div className="bg-white rounded-2xl shadow-lg p-6 sm:p-8">
            <div className="grid grid-cols-4 md:grid-cols-8 gap-6 sm:gap-8 items-center justify-items-center">
              {clientLogos.map((client, index) => <img key={index} src={client.src} alt={client.alt} className="max-h-8 sm:max-h-12 w-auto opacity-60 hover:opacity-100 transition-opacity grayscale hover:grayscale-0" />)}
            </div>
          </div>
        </div>
      </section>

      {/* Warning Section */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-amber-50">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-block p-4 bg-amber-500 rounded-full mb-6">
            <AlertTriangle className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mb-4">The AI Revolution Won't Wait</h2>
          <p className="text-lg sm:text-xl text-slate-700 leading-relaxed">
            AI won't take your job, but a person using AI will. This 3-hour AI Mastermind is your chance to get ahead. Don't become obsolete.
            This AI strategy course is the first step to becoming an indispensable AI generalist in your field.
          </p>
        </div>
      </section>

      <LearningOutcomes />
      <DetailedTestimonials />

      {/* Course Details Section */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-slate-100">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="px-4 py-2 text-sm font-semibold bg-blue-100 text-blue-800 rounded-full mb-4">Mastermind Details</Badge>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900">What You Get in 3 Hours</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-white shadow-lg rounded-2xl p-8 text-center">
              <Calendar className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Date</h3>
              <p className="text-lg text-slate-700">Tuesday, Sep 17th</p>
            </Card>
            <Card className="bg-white shadow-lg rounded-2xl p-8 text-center">
              <Clock className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Time</h3>
              <p className="text-lg text-slate-700">6 PM - 9 PM GST</p>
            </Card>
            <Card className="bg-white shadow-lg rounded-2xl p-8 text-center">
              <Monitor className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Platform</h3>
              <p className="text-lg text-slate-700">Live on Zoom</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Target Audience */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="px-4 py-2 text-sm font-semibold bg-slate-200 text-slate-800 rounded-full mb-4">Who Should Attend?</Badge>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900">Designed for Ambitious Professionals</h2>
            <p className="mt-4 text-lg text-slate-600">This AI for business leaders course is perfect if you want to apply AI without learning to code.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {targetAudience.map((audience, i) => (
              <Card key={i} className="text-center bg-slate-50 p-6 rounded-xl border-slate-200 hover:shadow-xl hover:-translate-y-1 transition-all">
                <audience.icon className="w-10 h-10 text-blue-600 mx-auto mb-4" />
                <h3 className="font-bold text-slate-800">{audience.title}</h3>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Bonuses Section */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <div className="max-w-5xl mx-auto text-center">
          <Badge className="px-4 py-2 text-sm font-semibold bg-white text-blue-800 rounded-full mb-4">Exclusive Bonuses</Badge>
          <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">Get Over $500 in FREE Bonuses</h2>
          <p className="text-lg text-blue-200 mb-12">Enroll today and receive these powerful resources to accelerate your AI journey.</p>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-white/10 backdrop-blur-sm p-8 rounded-2xl border border-white/20">
              <BookOpen className="w-12 h-12 text-yellow-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">200+ AI Prompt Library</h3>
              <p className="text-blue-200">($299 Value) - Instantly generate high-quality content for marketing, sales, and more.</p>
            </Card>
            <Card className="bg-white/10 backdrop-blur-sm p-8 rounded-2xl border border-white/20">
              <Bot className="w-12 h-12 text-yellow-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">15+ AI Tools Guide</h3>
              <p className="text-blue-200">($149 Value) - Master a curated list of top AI for productivity tools to automate your workflow.</p>
            </Card>
            <Card className="bg-white/10 backdrop-blur-sm p-8 rounded-2xl border border-white/20">
              <Infinity className="w-12 h-12 text-yellow-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Lifetime Access</h3>
              <p className="text-blue-200">($99 Value) - Get lifetime access to our community of AI professionals for networking and support.</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Instructor Section */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/5bb702e8b_Gaurav_SiFi.png" alt="Gaurav Oberoi, AI Expert" className="rounded-2xl shadow-2xl w-full" />
            </div>
            <div>
              <Badge className="px-4 py-2 text-sm font-semibold bg-slate-200 text-slate-800 rounded-full mb-4">Your Expert Instructor</Badge>
              <h2 className="text-3xl font-black text-slate-900 mb-4">Gaurav Oberoi</h2>
              <p className="text-lg text-slate-600 mb-6">With 15+ years of experience, Gaurav is a former Google Regional Trainer and consultant for iconic brands like Dubai Tourism and TikTok. He has trained over 9,000 professionals and is a leading voice in AI for business strategy.</p>
              <div className="space-y-3">
                <div className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-green-500" /><span>Trained 9,000+ professionals</span></div>
                <div className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-green-500" /><span>Former Google Regional Trainer</span></div>
                <div className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-green-500" /><span>Consultant for Expo 2020 & TikTok</span></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <ProfessionalFAQ />

      {/* Final CTA */}
      <section className="py-16 md:py-20 bg-slate-900 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl sm:text-4xl font-black mb-4">Your AI Future Starts Now</h2>
          <p className="text-lg text-slate-300 mb-8">For just $99, you get 3 hours of intensive AI training, over $500 in bonuses, and a clear path to becoming an AI leader. Don't miss out.</p>
          <PaymentButton courseType="mastermind-session" size="lg" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-10 py-5 text-xl font-bold rounded-xl shadow-lg transform hover:scale-105 transition-transform">
            Secure My Seat Now for $99
          </PaymentButton>
          <p className="text-sm text-slate-400 mt-4">100% Secure Checkout. Limited Seats Available.</p>
        </div>
      </section>
    </div>
  );
}