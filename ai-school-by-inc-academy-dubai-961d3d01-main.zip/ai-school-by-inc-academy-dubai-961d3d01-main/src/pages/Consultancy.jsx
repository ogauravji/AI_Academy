import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Target,
  Search,
  Wrench,
  GraduationCap,
  TrendingUp,
  CheckCircle2,
  ArrowRight,
  Users,
  Zap,
  Brain,
  Building,
  HeartHandshake,
  Compass,
  Map,
  BrainCircuit,
  DollarSign,
  Award,
  AlertTriangle,
  Lightbulb
} from "lucide-react";
import { motion } from "framer-motion";
import InquiryFormModal from "../components/common/InquiryFormModal";

const services = [
{
  icon: Target,
  title: "AI Strategy for Business",
  description: "Comprehensive AI roadmap aligned with your business objectives and market positioning",
  features: ["Strategic AI audit", "Implementation roadmap", "ROI projections", "Risk assessment"]
},
{
  icon: Wrench,
  title: "AI Agent Creation for Teams",
  description: "Custom AI agents designed for your specific workflows and business processes",
  features: ["Custom GPT development", "Workflow automation", "Integration setup", "Performance optimization"]
},
{
  icon: GraduationCap,
  title: "Internal Team Enablement",
  description: "Train your teams to maximize AI adoption with hands-on training and ongoing support",
  features: ["Team training programs", "Change management", "Adoption tracking", "Continuous improvement"]
},
{
  icon: TrendingUp,
  title: "Funnel & Campaign Automation",
  description: "AI-powered marketing funnels and campaign optimization for maximum performance",
  features: ["Funnel optimization", "Campaign automation", "Performance tracking", "A/B testing frameworks"]
}];


const processSteps = [
{
  step: 1,
  title: "Discovery",
  description: "Deep dive into your business, challenges, and AI opportunities",
  icon: Search,
  duration: "1-2 weeks"
},
{
  step: 2,
  title: "Audit",
  description: "Comprehensive analysis of current processes and AI readiness",
  icon: Target,
  duration: "1-2 weeks"
},
{
  step: 3,
  title: "Agent Design",
  description: "Custom AI solution architecture and development plan",
  icon: Wrench,
  duration: "2-3 weeks"
},
{
  step: 4,
  title: "Training & Onboarding",
  description: "Team training and smooth transition to AI-powered workflows",
  icon: GraduationCap,
  duration: "2-4 weeks"
},
{
  step: 5,
  title: "Results",
  description: "Monitor performance, optimize, and scale successful implementations",
  icon: TrendingUp,
  duration: "Ongoing"
}];


const caseStudies = [
{
  industry: "Real Estate",
  title: "Lead Gen via AI Chat Agents",
  challenge: "Manual lead qualification consuming 40+ hours weekly",
  solution: "Custom AI chat agent for property inquiries and lead scoring",
  results: ["85% reduction in manual work", "3x qualified lead increase", "24/7 customer engagement"],
  color: "blue"
},
{
  industry: "FMCG",
  title: "Campaign Optimization with Prompt Pipelines",
  challenge: "Inconsistent campaign performance across channels",
  solution: "AI-powered campaign creation and optimization system",
  results: ["200% increase in campaign ROI", "50% faster time-to-market", "Consistent brand messaging"],
  color: "green"
},
{
  industry: "B2B",
  title: "LinkedIn + Email AI Sequences",
  challenge: "Low response rates and time-intensive outreach",
  solution: "Personalized AI-driven outreach and follow-up automation",
  results: ["400% increase in response rates", "70% time savings", "$2M+ pipeline generated"],
  color: "red"
},
{
  industry: "Healthcare",
  title: "Patient Communication Automation",
  challenge: "High call volumes for routine queries and appointment scheduling",
  solution: "AI-powered chatbot handling FAQs, appointment booking, and reminders",
  results: ["60% reduction in administrative calls", "Improved patient satisfaction by 35%", "24/7 access to information"],
  color: "blue"
},
{
  industry: "Education",
  title: "Personalized Student Onboarding",
  challenge: "Generic onboarding process leading to low student engagement",
  solution: "AI agent to create personalized learning paths and onboarding materials",
  results: ["50% increase in student engagement", "Reduced onboarding time by 40%", "Personalized curriculum suggestions"],
  color: "orange"
},
{
  industry: "Hospitality",
  title: "AI-Powered Guest Experience Platform",
  challenge: "Poor guest satisfaction due to delayed responses and generic service",
  solution: "Multi-language AI concierge handling reservations, recommendations, and complaints",
  results: ["45% improvement in guest satisfaction scores", "24/7 multilingual support", "30% reduction in staff workload"],
  color: "green"
}];

const performanceFacts = [
{
  icon: TrendingUp,
  title: "40% Increase in Productivity",
  description: "Our strategic AI implementation automates repetitive tasks, freeing up your team to focus on high-value strategic initiatives.",
  color: "text-blue-600"
},
{
  icon: DollarSign,
  title: "Up to 70% Cost Reduction",
  description: "Optimize workflows and reduce operational overhead by leveraging AI for efficiency in marketing, sales, and customer service.",
  color: "text-green-600"
},
{
  icon: Zap,
  title: "5x Faster Decision Making",
  description: "Gain real-time insights from your business data, enabling your leadership to make faster, more informed strategic decisions.",
  color: "text-purple-600"
}];



export default function Consultancy() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState({ title: "", subtitle: "" });

  useEffect(() => {
    const setMetaTag = (attr, attrValue, content) => {
      let element = document.querySelector(`meta[${attr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const title = "AI Marketing Consultancy Dubai UAE | ChatGPT Strategy & Implementation - Inc. Academy";
    const description = "Leading AI marketing consultancy in Dubai UAE. Strategic ChatGPT implementation, prompt engineering, automation strategy & team training. Transform your business with AI experts in UAE.";
    const imageUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a54d506d6_Gaurav_SiFi.png";

    document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:url', window.location.href);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);
  }, []);

  const openModal = () => {
    setModalContent({
      title: "Book a Discovery Call",
      subtitle: "Let's discuss how our AI consultancy can transform your business."
    });
    setIsModalOpen(true);
  };

  const scrollToCaseStudies = () => {
    const caseStudiesSection = document.getElementById('case-studies');
    if (caseStudiesSection) {
      caseStudiesSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <InquiryFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={modalContent.title}
        subtitle={modalContent.subtitle} />

      <div className="min-h-screen bg-white">
        {/* Hero Section */}
        <section className="relative py-20 md:py-32 px-4 sm:px-6 lg:px-8 overflow-hidden bg-gray-900 text-white">
          {/* Background Gradient & Effects */}
          <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-blue-900 to-black opacity-80"></div>
          <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
          <div className="absolute top-20 -left-20 w-96 h-96 bg-gradient-to-r from-blue-500/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 -right-20 w-96 h-96 bg-gradient-to-r from-purple-500/20 to-transparent rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>

          <div className="relative max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Column: Text Content */}
            <div className="text-center lg:text-left">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="mb-6 md:mb-8"
              >
                <Badge className="px-6 py-3 text-base font-semibold bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-full shadow-lg">
                  <BrainCircuit className="w-5 h-5 mr-3" />
                  Strategic AI Implementation
                </Badge>
              </motion.div>
              
              <motion.h1
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="text-4xl sm:text-5xl md:text-6xl font-bold mb-8 leading-tight"
              >
                <span className="text-white block">AI Strategy &</span>
                <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent block mt-2">
                  Consultancy
                </span>
              </motion.h1>
              
              <motion.p
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="text-xl text-gray-300 mb-10 max-w-xl mx-auto lg:mx-0 leading-relaxed font-light"
              >
                From strategy to execution, we help businesses implement AI solutions that drive 
                measurable growth and operational efficiency.
              </motion.p>
              
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
              >
                <Button 
                  size="lg" 
                  className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-lg group transform hover:scale-105 transition-transform" 
                  onClick={openModal}
                >
                  Book Discovery Call
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
                
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="w-full sm:w-auto bg-white/10 backdrop-blur-md text-white border-2 border-white/30 hover:bg-white/20 px-8 py-4 text-lg font-semibold rounded-xl group" 
                  onClick={scrollToCaseStudies}
                >
                  View Case Studies
                </Button>
              </motion.div>
            </div >

            {/* Right Column: Image/Graphic */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.0, delay: 0.4, type: "spring", stiffness: 50 }}
              className="relative hidden lg:block"
            >
              <div className="w-full aspect-square bg-white/5 rounded-3xl shadow-2xl border border-white/10 p-4">
                <img 
                  src="https://images.unsplash.com/photo-1677756119517-756a188d2d94?q=80&w=2787&auto=format&fit=crop" 
                  alt="AI strategy implementation for businesses in Dubai UAE - advanced technology and automation" 
                  className="w-full h-full object-cover rounded-2xl"
                />
              </div>
            </motion.div>
          </div >
        </section >

        {/* Section Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent"></div>

        {/* AI Landscape Section */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50/70">
          <div className="max-w-7xl mx-auto">
            <motion.div 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8 }}
                className="text-center mb-12 md:mb-16">
              <Badge className="px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-blue-50 text-blue-700 border border-blue-200 mb-6 md:mb-8">
                <Compass className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Navigating the AI Revolution
              </Badge>
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 md:mb-6">
                The AI Landscape is 
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent block md:inline md:ml-3">
                  Complex. We Make it Simple.
                </span>
              </h2>
              <p className="text-lg sm:text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                New AI tools emerge daily, creating both massive opportunities and overwhelming confusion.
                A wrong turn can be costly. We provide the strategic map to navigate this landscape, ensuring your AI investments deliver real business value.
              </p>
            </motion.div>

            <motion.div 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="grid md:grid-cols-3 gap-8 text-center">
              
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 group rounded-2xl">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-red-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                    <Map className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">The Challenge</h3>
                  <p className="text-lg text-gray-600">Fragmented tools, unclear ROI, and the risk of falling behind competitors.</p>
                </CardContent>
              </Card>
              
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 group rounded-2xl">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                    <BrainCircuit className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="2xl font-bold text-gray-900 mb-3">The Opportunity</h3>
                  <p className="text-lg text-gray-600">Unprecedented gains in efficiency, personalization, and market intelligence.</p>
                </CardContent>
              </Card>
              
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 group rounded-2xl">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-teal-500 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                    <Target className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">Our Solution</h3>
                  <p className="text-lg text-gray-600">A clear, customized roadmap from strategy to implementation, focused on your unique goals.</p>
                </CardContent>
              </Card>

            </motion.div>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <motion.div 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8 }}
                className="text-center mb-12 md:mb-16">
              <Badge className="px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-blue-50 text-blue-700 border border-blue-200 mb-6 md:mb-8">
                <Zap className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Our Core Services
              </Badge>
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 md:mb-6 pb-2">
                Comprehensive AI 
                <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent"> Solutions</span>
              </h2>
              <p className="text-lg sm:text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                End-to-end AI implementation services designed to transform your business operations 
                and drive sustainable growth.
              </p>
            </motion.div>
            <div className="grid md:grid-cols-2 gap-8">
              {services.map((service, index) =>
              <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 40 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.3 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="h-full"
              >
                  <Card className="flex flex-col h-full rounded-3xl border border-gray-200 bg-white/80 backdrop-blur-sm shadow-xl hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 group">
                      <CardHeader className="p-8">
                          <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                              <service.icon className="w-8 h-8 text-white" />
                          </div>
                          <CardTitle className="text-2xl font-bold text-gray-900">
                              {service.title}
                          </CardTitle>
                          <p className="text-lg text-gray-600 leading-relaxed pt-2">
                              {service.description}
                          </p>
                      </CardHeader>
                      <CardContent className="p-8 pt-0 flex-grow flex flex-col">
                          <div className="space-y-3 flex-grow">
                              {service.features.map((feature, featureIndex) =>
                                  <div key={featureIndex} className="flex items-center gap-3">
                                      <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                                      <span className="text-gray-700">{feature}</span>
                                  </div>
                              )}
                          </div>
                      </CardContent>
                  </Card>
              </motion.div>
              )}
            </div>
          </div>
        </section>

        {/* How We Work Section */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-white to-gray-100">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <Badge className="px-6 py-3 text-base font-semibold bg-green-100 text-green-800 border border-green-200 mb-8 rounded-full">
                <Wrench className="w-5 h-5 mr-3" />
                Our Strategic Process
              </Badge>
              <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold text-gray-900 mb-6">
                A Proven Path to
                <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent block mt-2"> AI Success</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                Our methodology ensures a seamless journey from initial discovery to measurable business outcomes, de-risking your investment in AI.
              </p>
            </div>

            {/* Desktop Horizontal View */}
            <div className="hidden lg:flex flex-col items-center">
                <div className="flex w-full justify-between items-start">
                    {processSteps.map((step, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 50 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true, amount: 0.5 }}
                            transition={{ duration: 0.5, delay: index * 0.15 }}
                            className="w-[18%] text-center"
                        >
                            <div className="relative mb-6">
                                <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-blue-500 rounded-full flex items-center justify-center text-white font-extrabold text-3xl mx-auto shadow-lg ring-4 ring-white">
                                    {step.step}
                                </div>
                                {index < processSteps.length - 1 && (
                                    <div className="absolute top-1/2 left-full w-full h-0.5 bg-gray-300 -translate-y-1/2 ml-2"></div>
                                )}
                            </div>
                            <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-200/80 min-h-[280px]">
                                <step.icon className="w-10 h-10 text-blue-600 mx-auto mb-4" />
                                <h3 className="text-lg font-bold text-gray-900 mb-2">{step.title}</h3>
                                <p className="text-sm text-gray-600 mb-4">{step.description}</p>
                                <Badge variant="secondary" className="font-semibold">{step.duration}</Badge>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>


            {/* Mobile Vertical View */}
            <div className="lg:hidden space-y-12">
              {processSteps.map((step, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.3 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="flex items-start gap-6"
                >
                  <div className="relative">
                    <div className="w-16 h-16 bg-gradient-to-r from-green-600 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-2xl shadow-lg">
                      {step.step}
                    </div>
                    {index < processSteps.length - 1 && 
                      <div className="absolute top-full left-1/2 w-0.5 h-12 bg-gray-300 -translate-x-1/2 mt-2"></div>
                    }
                  </div>
                  <div className="flex-1">
                    <Badge variant="outline" className="mb-2">
                      {step.duration}
                    </Badge>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{step.title}</h3>
                    <p className="text-lg text-gray-600">{step.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Performance Facts Section */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12 md:mb-16">
              <Badge className="inline-flex items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent hover:bg-gray/80 px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-indigo-50 text-indigo-600 border-0 mb-6 md:mb-8">
                <TrendingUp className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                The ROI of Strategic AI
              </Badge>
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 md:mb-6 pb-2">
                Unlock 
                <span className="bg-gradient-to-r from-indigo-600 to-blue-600 bg-clip-text text-transparent"> Measurable Growth</span>
              </h2>
              <p className="text-lg sm:text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                Strategic AI consultancy isn't a cost—it's an investment in your company's future. 
                We focus on delivering tangible returns and building a sustainable competitive advantage.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-6 md:gap-8">
              {performanceFacts.map((fact, index) =>
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}>

                  <Card className="h-full border-0 shadow-lg hover:shadow-2xl transition-all duration-300 text-center">
                    <CardContent className="p-6 md:p-8">
                      <fact.icon className={`w-10 h-10 md:w-12 md:h-12 ${fact.color} mx-auto mb-4 md:mb-6`} />
                      <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-2 md:mb-4">{fact.title}</h3>
                      <p className="text-base md:text-lg text-gray-600 leading-relaxed">{fact.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </div>
          </div>
        </section>

        {/* Consultant Profile Section */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 via-blue-50/50 to-purple-50/50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12 md:mb-16">
              <Badge className="px-6 py-3 text-base font-semibold bg-white/70 text-blue-700 border border-blue-200 backdrop-blur-sm shadow-md mb-8">
                <Users className="w-5 h-5 mr-3" />
                Your Strategic Partner
              </Badge>
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 md:mb-6 pb-2">
                Meet Your Lead
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent block md:inline md:ml-4"> AI Consultant</span>
              </h2>
            </div>

            <div className="grid lg:grid-cols-5 gap-8 md:gap-12 items-center">
              {/* Image Column */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8, type: "spring" }}
                className="lg:col-span-2 relative"
              >
                <div className="relative z-10 p-2 bg-white/50 rounded-3xl shadow-2xl backdrop-blur-sm">
                  <img
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/1ed335269_Gaurav_SiFi.png"
                    alt="Gaurav Oberoi - Lead AI Marketing Consultant in Dubai UAE, expert in ChatGPT and business transformation"
                    className="w-full aspect-[4/5] object-cover rounded-2xl"
                  />
                </div>
                <div className="absolute -top-8 -left-8 w-32 h-32 bg-blue-200/50 rounded-full blur-2xl"></div>
                <div className="absolute -bottom-8 -right-8 w-40 h-40 bg-purple-200/50 rounded-full blur-2xl"></div>
              </motion.div>

              {/* Content Column */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8 }}
                className="lg:col-span-3 bg-white/80 backdrop-blur-md border border-gray-200/80 rounded-3xl p-8 md:p-12 shadow-xl"
              >
                <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Gaurav Oberoi</h3>
                <p className="text-xl md:text-2xl text-transparent bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text font-semibold mb-6">Founder & AI Transformation Expert</p>
                <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                  With over 15 years at the intersection of marketing and technology, Gaurav has guided more than 300 brands through digital transformations. As a former Google regional trainer and consultant for iconic projects like Expo 2020, he brings a rare blend of strategic foresight and practical, hands-on implementation skills.
                </p>
                <div className="space-y-4 mb-10">
                  <div className="flex items-start gap-4 p-4 bg-blue-50/70 rounded-xl border border-blue-200">
                    <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Award className="w-5 h-5" />
                    </div>
                    <p className="text-gray-700 font-medium">Proven track record with 9,000+ professionals trained</p>
                  </div>
                  <div className="flex items-start gap-4 p-4 bg-purple-50/70 rounded-xl border border-purple-200">
                    <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <Building className="w-5 h-5" />
                    </div>
                    <p className="text-gray-700 font-medium">Deep expertise in both enterprise and startup environments</p>
                  </div>
                  <div className="flex items-start gap-4 p-4 bg-green-50/70 rounded-xl border border-green-200">
                    <div className="w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <TrendingUp className="w-5 h-5" />
                    </div>
                    <p className="text-gray-700 font-medium">Focus on ROI-driven, sustainable AI strategies</p>
                  </div>
                </div>
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-purple-600 hover:shadow-lg hover:shadow-blue-500/40 text-white px-10 py-4 text-lg font-semibold rounded-2xl shadow-md transition-all duration-300 group"
                  onClick={openModal}
                >
                  Consult with Gaurav
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Case Studies */}
        <section id="case-studies" className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12 md:mb-16">
              <Badge className="px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-red-50 text-red-600 border-0 mb-6 md:mb-8">
                <TrendingUp className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Proven Success
              </Badge>
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 md:mb-6 pb-2">
                Case 
                <span className="text-red-600"> Studies</span>
              </h2>
              <p className="text-lg sm:text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                Real implementations, measurable results, and transformative business outcomes 
                across different industries
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              {caseStudies.map((study, index) => {
                const colors = {
                  blue: {
                    border: "border-blue-500",
                    text: "text-blue-600",
                    bg: "bg-blue-50",
                    badge: "border-blue-300 bg-blue-50 text-blue-700",
                  },
                  green: {
                    border: "border-green-500",
                    text: "text-green-600",
                    bg: "bg-green-50",
                    badge: "border-green-300 bg-green-50 text-green-700",
                  },
                  red: {
                    border: "border-red-500",
                    text: "text-red-600",
                    bg: "bg-red-50",
                    badge: "border-red-300 bg-red-50 text-red-700",
                  },
                  orange: {
                    border: "border-orange-500",
                    text: "text-orange-600",
                    bg: "bg-orange-50",
                    badge: "border-orange-300 bg-orange-50 text-orange-700",
                  },
                };
                const theme = colors[study.color] || colors.blue; // Fallback to blue if color not found

                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 40 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.3 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <Card className={`border-t-4 ${theme.border} shadow-lg hover:shadow-2xl transition-all duration-300 rounded-2xl overflow-hidden`}>
                      <CardHeader>
                        <Badge variant="outline" className={`mb-3 self-start ${theme.badge}`}>{study.industry}</Badge>
                        <CardTitle className="text-2xl font-bold text-gray-900">{study.title}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <div className="flex items-start gap-4">
                          <AlertTriangle className={`w-10 h-10 ${theme.text} flex-shrink-0 mt-1`} />
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-1">The Challenge</h4>
                            <p className="text-gray-600">{study.challenge}</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-4">
                          <Lightbulb className={`w-10 h-10 ${theme.text} flex-shrink-0 mt-1`} />
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-1">The Solution</h4>
                            <p className="text-gray-600">{study.solution}</p>
                          </div>
                        </div>
                        <div className={`p-6 rounded-lg ${theme.bg}`}>
                          <h4 className="font-semibold text-gray-900 mb-4">Key Results</h4>
                          <ul className="space-y-3">
                            {study.results.map((result, resultIndex) => (
                              <li key={resultIndex} className="flex items-center gap-3">
                                <CheckCircle2 className={`w-5 h-5 ${theme.text} flex-shrink-0`} />
                                <span className="text-gray-700 font-medium">{result}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-900 via-blue-900 to-black text-white relative overflow-hidden">
          {/* Background Gradient & Effects */}
          <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-blue-900 to-black opacity-80"></div>
          <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
          <div className="absolute top-20 -left-20 w-96 h-96 bg-gradient-to-r from-blue-500/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 -right-20 w-96 h-96 bg-gradient-to-r from-purple-500/20 to-transparent rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>

          <div className="relative max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8 }}
              className="mb-6 md:mb-8"
            >
              <Badge className="px-6 py-3 text-base font-semibold bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-full shadow-lg">
                <BrainCircuit className="w-5 h-5 mr-3" />
                Ready to Transform
              </Badge>
            </motion.div>

            <motion.h2
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 md:mb-6 leading-tight"
            >
              <span className="text-white block">Ready to Transform Your</span>
              <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent block mt-2">
                Business with AI?
              </span>
            </motion.h2>
            
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-lg sm:text-xl text-gray-300 mb-8 md:mb-12 max-w-3xl mx-auto leading-relaxed font-light"
            >
              Let's discuss your AI transformation journey. Book a discovery call to explore 
              how we can help you implement AI solutions that drive real business results.
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center"
            >
              <Button 
                size="lg" 
                className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-8 md:px-10 py-3 md:py-4 text-base md:text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 group transform hover:scale-105" 
                onClick={openModal}
              >
                Book Discovery Call
                <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button 
                size="lg" 
                variant="outline" 
                className="w-full sm:w-auto bg-white/10 backdrop-blur-md text-white border-2 border-white/30 hover:bg-white/20 px-8 md:px-10 py-3 md:py-4 text-base md:text-lg font-semibold rounded-xl group" 
                onClick={openModal}
              >
                Explore AI Agents
                <Zap className="w-4 h-4 md:w-5 md:h-5 ml-2" />
              </Button>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
}