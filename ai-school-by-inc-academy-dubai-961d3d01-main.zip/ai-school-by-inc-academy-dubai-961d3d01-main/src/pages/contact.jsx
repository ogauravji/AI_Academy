import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Mail, Phone, MessageCircle, MapPin } from 'lucide-react';
import InquiryFormModal from '@/components/common/InquiryFormModal';

export default function Contact() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <InquiryFormModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Book Discovery Call" subtitle="Schedule a call to discuss your AI needs." />
      <div className="min-h-screen bg-white">
        <div className="bg-gray-900 text-white py-20 sm:py-28 text-center">
          <Badge className="px-4 py-2 text-base font-semibold bg-white/10 text-white border border-white/20 mb-6">
            Get in Touch
          </Badge>
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold">Contact Us</h1>
          <p className="mt-4 text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto">
            We're here to help you navigate the world of AI. Reach out to us for any inquiries.
          </p>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1 space-y-8">
              <div className="bg-gray-50 p-6 rounded-lg">
                <Mail className="w-8 h-8 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold">Email Us</h3>
                <p className="text-gray-600">For general inquiries and support</p>
                <a href="mailto:hello@inc.academy" className="text-blue-600 hover:underline">hello@inc.academy</a>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <Phone className="w-8 h-8 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold">Call Us</h3>
                <p className="text-gray-600">Speak to our team directly</p>
                <a href="tel:+971524371377" className="text-blue-600 hover:underline">+971 52 437 1377</a>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <MapPin className="w-8 h-8 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold">Our Office</h3>
                <p className="text-gray-600">One JLT, Jumeirah Lake Towers, Dubai</p>
              </div>
            </div>

            <div className="lg:col-span-2 bg-gray-50 p-8 rounded-lg">
              <h2 className="text-3xl font-bold mb-6">Send us a message</h2>
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                    <Input id="name" placeholder="Your Name" className="mt-1" />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                    <Input id="email" type="email" placeholder="you@example.com" className="mt-1" />
                  </div>
                </div>
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700">Subject</label>
                  <Input id="subject" placeholder="Inquiry about AI Courses" className="mt-1" />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700">Message</label>
                  <Textarea id="message" placeholder="Your message..." rows={5} className="mt-1" />
                </div>
                <div>
                  <Button type="submit" size="lg" className="w-full" onClick={() => setIsModalOpen(true)}>Send Message</Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}