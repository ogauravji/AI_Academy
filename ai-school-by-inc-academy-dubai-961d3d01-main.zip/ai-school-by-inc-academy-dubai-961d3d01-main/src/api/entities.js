import { base44 } from './base44Client';


export const Enrollment = base44.entities.Enrollment;

export const Inquiry = base44.entities.Inquiry;



// auth sdk:
export const User = base44.auth;